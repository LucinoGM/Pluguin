package com.ranktab;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class CreateRankCommand implements CommandExecutor {

    private final RankTab plugin;

    public CreateRankCommand(RankTab plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ranktab.createrank")) {
            sender.sendMessage(plugin.getLangManager().get("cargo.sem_permissao"));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(plugin.getLangManager().get("cargo.uso_createrank"));
            return true;
        }

        String nome = args[0];
        boolean criado = plugin.getCargoManager().criarCargo(nome);
        if (!criado) {
            sender.sendMessage(plugin.getLangManager().get("cargo.invalido"));
            return true;
        }

        sender.sendMessage(plugin.getLangManager().get("cargo.criado", LangManager.de("cargo", nome)));
        sender.sendMessage(plugin.getLangManager().get("cargo.cor_hint", LangManager.de("nome", nome)));

        Bukkit.getOnlinePlayers().forEach(p -> plugin.getTabManager().updateTab(p));
        return true;
    }
}
