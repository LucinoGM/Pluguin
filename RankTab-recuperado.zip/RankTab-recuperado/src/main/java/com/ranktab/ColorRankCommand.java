package com.ranktab;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;

public class ColorRankCommand implements CommandExecutor, TabCompleter {

    private final RankTab plugin;

    public ColorRankCommand(RankTab plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ranktab.colorrank")) {
            sender.sendMessage(plugin.getLangManager().get("cargo.sem_permissao"));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(plugin.getLangManager().get("cargo.uso_colorrank"));
            return true;
        }

        String cargo = args[0];
        if (!plugin.getCargoManager().cargoExiste(cargo)) {
            sender.sendMessage(plugin.getLangManager().get("cargo.nao_existe"));
            return true;
        }

        String cor = args[1].toLowerCase();
        if (!plugin.getCargoManager().setCorCargo(cargo, cor)) {
            sender.sendMessage(plugin.getLangManager().get("cargo.cor_invalida"));
            return true;
        }

        sender.sendMessage(plugin.getLangManager().get("cargo.cor_alterada",
                LangManager.de("cargo", cargo, "cor", cor)));
        Bukkit.getOnlinePlayers().forEach(p -> plugin.getTabManager().updateTab(p));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> sugestoes = new ArrayList<>();
        if (!sender.hasPermission("ranktab.colorrank")) return sugestoes;

        if (args.length == 1) {
            for (String cargo : plugin.getCargoManager().getTodosCargos()) {
                if (cargo.toLowerCase().startsWith(args[0].toLowerCase())) {
                    sugestoes.add(cargo);
                }
            }
        } else if (args.length == 2) {
            for (String cor : CargoManager.CORES_DISPONIVEIS) {
                if (cor.startsWith(args[1].toLowerCase())) {
                    sugestoes.add(cor);
                }
            }
        }
        return sugestoes;
    }
}
