package com.ranktab;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class RemoveRankCommand implements CommandExecutor, TabCompleter {

    private final RankTab plugin;

    public RemoveRankCommand(RankTab plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ranktab.removerank")) {
            sender.sendMessage(plugin.getLangManager().get("cargo.sem_permissao"));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(plugin.getLangManager().get("cargo.uso_removerank"));
            return true;
        }

        String cargo = args[0];
        if (!plugin.getCargoManager().cargoExiste(cargo)) {
            sender.sendMessage(plugin.getLangManager().get("cargo.nao_existe"));
            return true;
        }

        // tira o cargo de quem estiver com ele
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (plugin.getCargoManager().getCargo(p).equals(cargo)) {
                plugin.getCargoManager().removerCargo(p);
            }
        }
        plugin.getCargoManager().deletarCargo(cargo);

        sender.sendMessage(plugin.getLangManager().get("cargo.removido", LangManager.de("cargo", cargo)));
        Bukkit.getOnlinePlayers().forEach(p -> plugin.getTabManager().updateTab(p));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> sugestoes = new ArrayList<>();
        if (!sender.hasPermission("ranktab.removerank")) return sugestoes;

        if (args.length == 1) {
            for (String cargo : plugin.getCargoManager().getTodosCargos()) {
                if (cargo.toLowerCase().startsWith(args[0].toLowerCase())) {
                    sugestoes.add(cargo);
                }
            }
        }
        return sugestoes;
    }
}
