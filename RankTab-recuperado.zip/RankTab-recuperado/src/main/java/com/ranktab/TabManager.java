package com.ranktab;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.ArrayList;
import java.util.List;

public class TabManager {

    private static final NamedTextColor[] DEFAULT_WAVE_COLORS = {
            NamedTextColor.RED, NamedTextColor.GOLD, NamedTextColor.YELLOW, NamedTextColor.GREEN,
            NamedTextColor.AQUA, NamedTextColor.BLUE, NamedTextColor.LIGHT_PURPLE, NamedTextColor.DARK_PURPLE
    };
    private static final int BLOCK = 4;

    private final RankTab plugin;
    private int corIndex = 0;

    public TabManager(RankTab plugin) {
        this.plugin = plugin;
    }

    public void updateTab(Player player) {
        int online = Bukkit.getOnlinePlayers().size();
        int ping = player.getPing();

        String titulo = plugin.getConfig().getString("tab-titulo", "HyBased");
        TextColor cor = parseColor(plugin.getConfig().getString("tab-color", "gold"));
        boolean ondaAtiva = plugin.getConfig().getBoolean("tab-wave-enabled", false);
        String estilo = plugin.getConfig().getString("tab-wave-style", "solid").toLowerCase();
        TextColor[] coresOnda = getConfiguredWaveColors();
        boolean mostrarJogadores = plugin.getConfig().getBoolean("tab-mostrar-jogadores", true);
        boolean mostrarPing = plugin.getConfig().getBoolean("tab-mostrar-ping", true);

        Component header = Component.newline()
                .append(buildHeaderTitle(titulo, cor, ondaAtiva, estilo, coresOnda))
                .append(Component.newline());

        Component footer = Component.newline();
        if (mostrarJogadores) {
            footer = footer
                    .append(Component.text("⚔ Jogadores Online: ", NamedTextColor.GRAY))
                    .append(Component.text(String.valueOf(online), NamedTextColor.GREEN, TextDecoration.BOLD))
                    .append(Component.newline());
        }
        if (mostrarPing) {
            footer = footer
                    .append(Component.text("📶 Ping: ", NamedTextColor.GRAY))
                    .append(pingColor(ping))
                    .append(Component.newline());
        }
        if (!mostrarJogadores && !mostrarPing) {
            footer = Component.empty();
        }

        player.sendPlayerListHeaderAndFooter(header, footer);
        aplicarScoreboard(player);

        corIndex = (corIndex + 1) % (coresOnda.length * BLOCK);
    }

    private Component buildWave(String texto, TextColor[] cores) {
        Component resultado = Component.empty();
        for (int i = 0; i < texto.length(); i++) {
            int idx = (i + corIndex) / BLOCK;
            TextColor c = cores[idx % cores.length];
            resultado = resultado.append(Component.text(String.valueOf(texto.charAt(i)), c, TextDecoration.BOLD));
        }
        return resultado;
    }

    private Component buildSolidWave(String texto, TextColor cor) {
        Component resultado = Component.empty();
        for (int i = 0; i < texto.length(); i++) {
            resultado = resultado.append(Component.text(String.valueOf(texto.charAt(i)), cor, TextDecoration.BOLD));
        }
        return resultado;
    }

    private Component buildStaticTitle(String texto, TextColor cor) {
        return Component.text(texto, cor, TextDecoration.BOLD);
    }

    private Component buildHeaderTitle(String titulo, TextColor cor, boolean ondaAtiva, String estilo, TextColor[] cores) {
        if (!ondaAtiva) return buildStaticTitle(titulo, cor);
        if ("rainbow".equals(estilo)) return buildWave(titulo, cores);
        if ("solid".equals(estilo)) return buildSolidWave(titulo, cor);
        return buildStaticTitle(titulo, cor);
    }

    private TextColor[] getConfiguredWaveColors() {
        List<String> lista = plugin.getConfig().getStringList("tab-wave-colors");
        if (lista == null || lista.isEmpty()) return DEFAULT_WAVE_COLORS;

        List<TextColor> cores = new ArrayList<>();
        for (String s : lista) {
            TextColor c = parseColor(s);
            if (c != null) cores.add(c);
        }
        if (cores.isEmpty()) return DEFAULT_WAVE_COLORS;
        return cores.toArray(new TextColor[0]);
    }

    private TextColor parseColor(String nome) {
        if (nome == null) return NamedTextColor.GOLD;
        String n = nome.toLowerCase().trim();

        if (n.startsWith("#") && n.length() == 7) {
            try {
                return TextColor.color(Integer.parseInt(n.substring(1), 16));
            } catch (NumberFormatException ignored) {
            }
        }

        return switch (n) {
            case "aqua" -> NamedTextColor.AQUA;
            case "red" -> NamedTextColor.RED;
            case "dark_blue" -> NamedTextColor.DARK_BLUE;
            case "gold" -> NamedTextColor.GOLD;
            case "green" -> NamedTextColor.GREEN;
            case "yellow" -> NamedTextColor.YELLOW;
            case "dark_green" -> NamedTextColor.DARK_GREEN;
            case "dark_red" -> NamedTextColor.DARK_RED;
            case "dark_purple" -> NamedTextColor.DARK_PURPLE;
            case "light_purple" -> NamedTextColor.LIGHT_PURPLE;
            case "white" -> NamedTextColor.WHITE;
            case "gray" -> NamedTextColor.GRAY;
            case "dark_gray" -> NamedTextColor.DARK_GRAY;
            case "dark_aqua" -> NamedTextColor.DARK_AQUA;
            default -> NamedTextColor.GOLD;
        };
    }

    /** Cada jogador ganha um time no scoreboard com o cargo como prefixo (aparece no tab). */
    private void aplicarScoreboard(Player player) {
        Scoreboard sb = player.getScoreboard();
        if (sb == Bukkit.getScoreboardManager().getMainScoreboard()) {
            sb = Bukkit.getScoreboardManager().getNewScoreboard();
            player.setScoreboard(sb);
        }

        for (Player p : Bukkit.getOnlinePlayers()) {
            String nomeTime = "rt_" + p.getName().toLowerCase();
            if (nomeTime.length() > 16) nomeTime = nomeTime.substring(0, 16);

            Team time = sb.getTeam(nomeTime);
            if (time == null) {
                time = sb.registerNewTeam(nomeTime);
                time.addEntry(p.getName());
            }

            String cargo = plugin.getCargoManager().getCargo(p);
            if (!cargo.isEmpty() && plugin.getCargoManager().cargoExiste(cargo)) {
                time.prefix(Component.text("[" + cargo + "] ",
                        plugin.getCargoManager().getCorCargo(cargo), TextDecoration.BOLD));
            } else {
                time.prefix(Component.empty());
            }
        }
    }

    private Component pingColor(int ping) {
        NamedTextColor cor = ping < 80 ? NamedTextColor.GREEN
                : ping < 180 ? NamedTextColor.YELLOW
                : NamedTextColor.RED;
        return Component.text(ping + "ms", cor, TextDecoration.BOLD);
    }

    public void resetTab(Player player) {
        player.sendPlayerListHeaderAndFooter(Component.empty(), Component.empty());
    }
}
