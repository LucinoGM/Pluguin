package com.ranktab;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class LangManager {

    private static final String[] LANGS_VALIDAS = {
            "en", "pt_br", "pt_pt", "es", "fr", "de", "it", "nl", "ru", "ja", "ko", "zh_cn", "zh_tw", "ar"
    };

    private final RankTab plugin;
    private FileConfiguration lang;
    private String langCode;

    public LangManager(RankTab plugin) {
        this.plugin = plugin;
        carregar();
    }

    private void carregar() {
        langCode = plugin.getConfig().getString("lang", "en").toLowerCase();

        boolean valida = false;
        for (String l : LANGS_VALIDAS) {
            if (l.equals(langCode)) {
                valida = true;
                break;
            }
        }
        if (!valida) langCode = "en";

        File langFolder = new File(plugin.getDataFolder(), "lang");
        if (!langFolder.exists()) langFolder.mkdirs();

        // copia os idiomas que ainda não existem na pasta do plugin
        for (String l : LANGS_VALIDAS) {
            File f = new File(langFolder, l + ".yml");
            if (!f.exists()) plugin.saveResource("lang/" + l + ".yml", false);
        }

        File langFile = new File(langFolder, langCode + ".yml");
        lang = YamlConfiguration.loadConfiguration(langFile);

        InputStream padrao = plugin.getResource("lang/" + langCode + ".yml");
        if (padrao != null) {
            lang.setDefaults(YamlConfiguration.loadConfiguration(
                    new InputStreamReader(padrao, StandardCharsets.UTF_8)));
        }
    }

    public String get(String key, Map<String, String> placeholders) {
        String msg = lang.getString(key, "&cChave não encontrada: " + key);
        msg = msg.replace("%plugin%", plugin.getName());
        msg = msg.replace("%server%", plugin.getConfig().getString("server", "Servidor"));
        msg = msg.replace("%version%", plugin.getDescription().getVersion());
        if (placeholders != null) {
            for (Map.Entry<String, String> e : placeholders.entrySet()) {
                msg = msg.replace("{" + e.getKey() + "}", e.getValue());
            }
        }
        return colorir(msg);
    }

    public String get(String key) {
        return get(key, null);
    }

    public void log(String key) {
        plugin.getServer().getConsoleSender().sendMessage(get(key));
    }

    public void log(String key, Map<String, String> placeholders) {
        plugin.getServer().getConsoleSender().sendMessage(get(key, placeholders));
    }

    public String getLangCode() {
        return langCode;
    }

    public static String colorir(String s) {
        return s.replace("&", "§");
    }

    /** Monta um mapa de placeholders a partir de pares chave, valor, chave, valor... */
    public static Map<String, String> de(String... pares) {
        Map<String, String> mapa = new HashMap<>();
        for (int i = 0; i + 1 < pares.length; i += 2) {
            mapa.put(pares[i], pares[i + 1]);
        }
        return mapa;
    }
}
