package com.ranktab;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class SetRankCommand implements CommandExecutor, TabCompleter {

    private final RankTab plugin;

    public SetRankCommand(RankTab plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ranktab.setrank")) {
            sender.sendMessage(plugin.getLangManager().get("cargo.sem_permissao"));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(plugin.getLangManager().get("cargo.uso_setrank"));
            return true;
        }

        Player alvo = Bukkit.getPlayer(args[0]);
        if (alvo == null) {
            sender.sendMessage(plugin.getLangManager().get("cargo.nao_encontrado",
                    LangManager.de("player", args[0])));
            return true;
        }

        String cargo = args[1];
        if (!plugin.getCargoManager().cargoExiste(cargo)) {
            sender.sendMessage(plugin.getLangManager().get("cargo.nao_existe"));
            return true;
        }

        plugin.getCargoManager().setCargo(alvo, cargo);
        sender.sendMessage(plugin.getLangManager().get("cargo.definido",
                LangManager.de("cargo", cargo, "player", alvo.getName())));
        alvo.sendMessage(plugin.getLangManager().get("cargo.recebido",
                LangManager.de("cargo", cargo)));

        Bukkit.getOnlinePlayers().forEach(p -> plugin.getTabManager().updateTab(p));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> sugestoes = new ArrayList<>();
        if (!sender.hasPermission("ranktab.setrank")) return sugestoes;

        if (args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[0].toLowerCase())) {
                    sugestoes.add(p.getName());
                }
            }
        } else if (args.length == 2) {
            for (String cargo : plugin.getCargoManager().getTodosCargos()) {
                if (cargo.toLowerCase().startsWith(args[1].toLowerCase())) {
                    sugestoes.add(cargo);
                }
            }
        }
        return sugestoes;
    }
}
