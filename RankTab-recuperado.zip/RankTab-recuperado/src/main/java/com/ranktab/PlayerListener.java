package com.ranktab;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scoreboard.Team;

public class PlayerListener implements Listener {

    private final RankTab plugin;

    public PlayerListener(RankTab plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> plugin.getServer().getOnlinePlayers()
                        .forEach(p -> plugin.getTabManager().updateTab(p)),
                5L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player saiu = event.getPlayer();
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            for (Player p : plugin.getServer().getOnlinePlayers()) {
                String nomeTime = "rt_" + saiu.getName().toLowerCase();
                if (nomeTime.length() > 16) nomeTime = nomeTime.substring(0, 16);

                Team time = p.getScoreboard().getTeam(nomeTime);
                if (time != null) time.unregister();
                plugin.getTabManager().updateTab(p);
            }
        }, 1L);
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onChat(AsyncChatEvent event) {
        event.setCancelled(true);
        Player player = event.getPlayer();
        String cargo = plugin.getCargoManager().getCargo(player);

        Component prefixo = Component.empty();
        if (!cargo.isEmpty() && plugin.getCargoManager().cargoExiste(cargo)) {
            prefixo = Component.text("[" + cargo + "] ",
                    plugin.getCargoManager().getCorCargo(cargo), TextDecoration.BOLD);
        }

        Component mensagem = prefixo
                .append(Component.text(player.getName(), NamedTextColor.WHITE))
                .append(Component.text(": ", NamedTextColor.GRAY))
                .append(event.message());

        plugin.getServer().getOnlinePlayers().forEach(p -> p.sendMessage(mensagem));
        plugin.getServer().getConsoleSender().sendMessage(mensagem);
    }
}
