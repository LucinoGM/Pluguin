package com.ranktab;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ListRanksCommand implements CommandExecutor {

    private final RankTab plugin;

    public ListRanksCommand(RankTab plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ranktab.listranks")) {
            sender.sendMessage(plugin.getLangManager().get("cargo.sem_permissao"));
            return true;
        }

        if (plugin.getCargoManager().getTodosCargos().isEmpty()) {
            sender.sendMessage(plugin.getLangManager().get("cargo.lista_vazia"));
            return true;
        }

        sender.sendMessage(plugin.getLangManager().get("cargo.lista_header"));
        int id = 1;
        for (String cargo : plugin.getCargoManager().getTodosCargos()) {
            String cor = plugin.getCargoManager().getCorStr(cargo);
            sender.sendMessage(plugin.getLangManager().get("cargo.lista_item",
                    LangManager.de("id", String.valueOf(id++), "cargo", cargo, "cor", cor)));
        }
        return true;
    }
}
