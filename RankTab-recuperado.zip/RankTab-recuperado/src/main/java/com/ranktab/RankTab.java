package com.ranktab;

import org.bukkit.plugin.java.JavaPlugin;

public class RankTab extends JavaPlugin {

    private static RankTab instance;
    private LangManager langManager;
    private CargoManager cargoManager;
    private TabManager tabManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        langManager = new LangManager(this);
        cargoManager = new CargoManager(this);
        tabManager = new TabManager(this);

        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        registrarComandos();

        // atualiza o tab de todos a cada segundo
        getServer().getScheduler().runTaskTimer(this,
                () -> getServer().getOnlinePlayers().forEach(p -> tabManager.updateTab(p)),
                20L, 20L);

        exibirBoot();
    }

    private void exibirBoot() {
        langManager.log("startup.loading");
        langManager.log("startup.loaded");
        langManager.log("startup.loaded2");
        langManager.log("startup.loaded3");
        langManager.log("startup.loaded4");
        langManager.log("startup.loaded5");
        langManager.log("startup.loaded6");
    }

    private void registrarComandos() {
        SetRankCommand setRank = new SetRankCommand(this);
        getCommand("setrank").setExecutor(setRank);
        getCommand("setrank").setTabCompleter(setRank);

        CreateRankCommand createRank = new CreateRankCommand(this);
        getCommand("createrank").setExecutor(createRank);

        ColorRankCommand colorRank = new ColorRankCommand(this);
        getCommand("colorrank").setExecutor(colorRank);
        getCommand("colorrank").setTabCompleter(colorRank);

        ListRanksCommand listRanks = new ListRanksCommand(this);
        getCommand("listranks").setExecutor(listRanks);

        RemoveRankCommand removeRank = new RemoveRankCommand(this);
        getCommand("removerank").setExecutor(removeRank);
        getCommand("removerank").setTabCompleter(removeRank);
    }

    @Override
    public void onDisable() {
        if (tabManager != null) {
            getServer().getOnlinePlayers().forEach(p -> tabManager.resetTab(p));
        }
        langManager.log("startup.disabled");
    }

    public static RankTab getInstance() {
        return instance;
    }

    public LangManager getLangManager() {
        return langManager;
    }

    public CargoManager getCargoManager() {
        return cargoManager;
    }

    public TabManager getTabManager() {
        return tabManager;
    }
}
