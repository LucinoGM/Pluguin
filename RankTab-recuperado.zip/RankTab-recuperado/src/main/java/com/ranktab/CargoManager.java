package com.ranktab;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class CargoManager {

    private final RankTab plugin;
    private final Map<UUID, String> playerCargos = new HashMap<>();
    private final Map<String, String> cargoCores = new LinkedHashMap<>();
    private File dataFile;
    private FileConfiguration dataConfig;

    private static final Random RANDOM = new Random();

    public static final String[] CORES_DISPONIVEIS = {
            "aqua", "red", "dark_blue", "gold", "green", "yellow", "dark_green",
            "dark_red", "dark_purple", "light_purple", "white", "gray", "dark_gray", "dark_aqua"
    };

    public CargoManager(RankTab plugin) {
        this.plugin = plugin;
        carregar();
    }

    private void carregar() {
        dataFile = new File(plugin.getDataFolder(), "cargos.yml");
        if (!dataFile.exists()) {
            try {
                dataFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Erro ao criar cargos.yml");
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);

        ConfigurationSection cargos = dataConfig.getConfigurationSection("cargos");
        if (cargos != null) {
            for (String key : cargos.getKeys(false)) {
                String cor = dataConfig.getString("cargos." + key + ".cor", "white");
                cargoCores.put(key, cor);
            }
        }

        ConfigurationSection players = dataConfig.getConfigurationSection("players");
        if (players != null) {
            for (String key : players.getKeys(false)) {
                try {
                    playerCargos.put(UUID.fromString(key), dataConfig.getString("players." + key, ""));
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void salvar() {
        dataConfig.set("cargos", null);
        for (Map.Entry<String, String> e : cargoCores.entrySet()) {
            dataConfig.set("cargos." + e.getKey() + ".cor", e.getValue());
        }
        playerCargos.forEach((uuid, cargo) -> dataConfig.set("players." + uuid, cargo));
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Erro ao salvar cargos.yml");
        }
    }

    /** Cria o cargo com uma cor aleatória. Retorna false se já existir. */
    public boolean criarCargo(String nome) {
        if (cargoCores.containsKey(nome)) return false;
        String cor = CORES_DISPONIVEIS[RANDOM.nextInt(CORES_DISPONIVEIS.length)];
        cargoCores.put(nome, cor);
        salvar();
        return true;
    }

    public boolean cargoExiste(String nome) {
        return cargoCores.containsKey(nome);
    }

    public Set<String> getTodosCargos() {
        return Collections.unmodifiableSet(cargoCores.keySet());
    }

    public String getCorStr(String cargo) {
        return cargoCores.getOrDefault(cargo, "white");
    }

    public String getCargo(Player player) {
        return playerCargos.getOrDefault(player.getUniqueId(), "");
    }

    public void setCargo(Player player, String cargo) {
        playerCargos.put(player.getUniqueId(), cargo);
        salvar();
    }

    public void removerCargo(Player player) {
        playerCargos.remove(player.getUniqueId());
        salvar();
    }

    public void deletarCargo(String cargo) {
        cargoCores.remove(cargo);
        salvar();
    }

    public boolean setCorCargo(String cargo, String cor) {
        if (!cargoCores.containsKey(cargo) || parseColor(cor) == null) return false;
        cargoCores.put(cargo, cor.toLowerCase());
        salvar();
        return true;
    }

    public NamedTextColor getCorCargo(String cargo) {
        return parseColor(cargoCores.getOrDefault(cargo, "white"));
    }

    public NamedTextColor parseColor(String nome) {
        if (nome == null) return NamedTextColor.WHITE;
        String n = nome.toLowerCase().replace("-", "_");
        return switch (n) {
            case "aqua" -> NamedTextColor.AQUA;
            case "red" -> NamedTextColor.RED;
            case "dark_blue" -> NamedTextColor.DARK_BLUE;
            case "gold" -> NamedTextColor.GOLD;
            case "green" -> NamedTextColor.GREEN;
            case "yellow" -> NamedTextColor.YELLOW;
            case "dark_green" -> NamedTextColor.DARK_GREEN;
            case "dark_red" -> NamedTextColor.DARK_RED;
            case "dark_purple" -> NamedTextColor.DARK_PURPLE;
            case "light_purple" -> NamedTextColor.LIGHT_PURPLE;
            case "white" -> NamedTextColor.WHITE;
            case "gray" -> NamedTextColor.GRAY;
            case "dark_gray" -> NamedTextColor.DARK_GRAY;
            case "dark_aqua" -> NamedTextColor.DARK_AQUA;
            default -> null;
        };
    }
}
