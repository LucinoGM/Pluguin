package com.whyguild.home;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DatabaseManager {

    private Connection connection;
    private final PaperHomePlugin plugin;

    public DatabaseManager(PaperHomePlugin plugin) {
        this.plugin = plugin;
    }

    public void init() {
        try {
            File dataFolder = plugin.getDataFolder();
            if (!dataFolder.exists()) {
                dataFolder.mkdirs();
            }

            String url = "jdbc:sqlite:" + dataFolder.getAbsolutePath() + File.separator + "homes.db";
            connection = DriverManager.getConnection(url);

            createTables();
            plugin.getLogger().info("§a[Banco de Dados] SQLite conectado com sucesso!");

        } catch (SQLException e) {
            plugin.getLogger().severe("§c[ERRO] Falha ao conectar no banco de dados: " + e.getMessage());
        }
    }

    private void createTables() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS homes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "player_uuid TEXT NOT NULL," +
                "player_name TEXT NOT NULL," +
                "home_name TEXT NOT NULL," +
                "world TEXT NOT NULL," +
                "x REAL NOT NULL," +
                "y REAL NOT NULL," +
                "z REAL NOT NULL," +
                "yaw REAL NOT NULL," +
                "pitch REAL NOT NULL," +
                "icon TEXT DEFAULT 'DIRT'," +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                "UNIQUE(player_uuid, home_name)" +
                ")";

        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        }
    }

    public void saveHome(UUID playerUUID, String playerName, String homeName, Location location, String icon) {
        String sql = "INSERT OR REPLACE INTO homes (player_uuid, player_name, home_name, world, x, y, z, yaw, pitch, icon) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, playerUUID.toString());
            pstmt.setString(2, playerName);
            pstmt.setString(3, homeName.toLowerCase());
            pstmt.setString(4, location.getWorld().getName());
            pstmt.setDouble(5, location.getX());
            pstmt.setDouble(6, location.getY());
            pstmt.setDouble(7, location.getZ());
            pstmt.setFloat(8, location.getYaw());
            pstmt.setFloat(9, location.getPitch());
            pstmt.setString(10, icon);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("§c[ERRO] Falha ao salvar home: " + e.getMessage());
        }
    }

    public HomeData getHome(UUID playerUUID, String homeName) {
        String sql = "SELECT * FROM homes WHERE player_uuid = ? AND home_name = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, playerUUID.toString());
            pstmt.setString(2, homeName.toLowerCase());

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return resultSetToHome(rs);
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("§c[ERRO] Falha ao buscar home: " + e.getMessage());
        }
        return null;
    }

    public List<HomeData> getPlayerHomes(UUID playerUUID) {
        List<HomeData> homes = new ArrayList<>();
        String sql = "SELECT * FROM homes WHERE player_uuid = ? ORDER BY created_at";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, playerUUID.toString());
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                homes.add(resultSetToHome(rs));
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("§c[ERRO] Falha ao buscar homes: " + e.getMessage());
        }
        return homes;
    }

    public void deleteHome(UUID playerUUID, String homeName) {
        String sql = "DELETE FROM homes WHERE player_uuid = ? AND home_name = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, playerUUID.toString());
            pstmt.setString(2, homeName.toLowerCase());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("§c[ERRO] Falha ao deletar home: " + e.getMessage());
        }
    }

    public void updateHomeIcon(UUID playerUUID, String homeName, String icon) {
        String sql = "UPDATE homes SET icon = ? WHERE player_uuid = ? AND home_name = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, icon);
            pstmt.setString(2, playerUUID.toString());
            pstmt.setString(3, homeName.toLowerCase());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("§c[ERRO] Falha ao atualizar ícone: " + e.getMessage());
        }
    }

    public int getHomeCount(UUID playerUUID) {
        String sql = "SELECT COUNT(*) FROM homes WHERE player_uuid = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, playerUUID.toString());
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("§c[ERRO] Falha ao contar homes: " + e.getMessage());
        }
        return 0;
    }

    private HomeData resultSetToHome(ResultSet rs) throws SQLException {
        String worldName = rs.getString("world");
        World world = Bukkit.getWorld(worldName);

        if (world == null) {
            world = Bukkit.getWorlds().get(0);
        }

        Location location = new Location(
                world,
                rs.getDouble("x"),
                rs.getDouble("y"),
                rs.getDouble("z"),
                rs.getFloat("yaw"),
                rs.getFloat("pitch")
        );

        return new HomeData(
                UUID.fromString(rs.getString("player_uuid")),
                rs.getString("player_name"),
                rs.getString("home_name"),
                location,
                rs.getString("icon")
        );
    }

    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("§c[ERRO] Falha ao fechar banco: " + e.getMessage());
        }
    }
}
