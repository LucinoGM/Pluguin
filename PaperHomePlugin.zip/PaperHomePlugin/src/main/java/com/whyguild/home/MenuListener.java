package com.whyguild.home;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class MenuListener implements Listener {

    private final HomeManager homeManager;

    // Armazena qual jogador está editando qual home (para o seletor de ícones)
    private static final Map<UUID, String> editingHome = new HashMap<>();

    public MenuListener(HomeManager homeManager) {
        this.homeManager = homeManager;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;

        Player player = (Player) event.getWhoClicked();
        String title = event.getView().getTitle();

        // Menu de seleção de ícone
        if (title.equals("§8§lSelecionar Ícone")) {
            event.setCancelled(true);

            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || clicked.getType() == Material.AIR) return;

            String homeName = editingHome.get(player.getUniqueId());
            if (homeName == null) return;

            Material selectedMaterial = clicked.getType();
            homeManager.updateHomeIcon(player.getUniqueId(), homeName, selectedMaterial.name());

            player.sendMessage("§a§l✔ §aÍcone da home §e" + homeName + " §aalterado para §f" + formatMaterialName(selectedMaterial.name()) + "§a!");
            editingHome.remove(player.getUniqueId());

            Bukkit.getScheduler().runTaskLater(PaperHomePlugin.getInstance(), () -> {
                player.closeInventory();
            }, 10L);

            return;
        }

        // Menu principal de homes
        if (!title.contains("Casas") && !title.contains("casas")) return;

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;
        if (clicked.getType() == Material.BLACK_STAINED_GLASS_PANE) return;

        ItemMeta meta = clicked.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) return;

        String displayName = meta.getDisplayName();
        String homeName = displayName.replace("§e§l", "").toLowerCase();

        boolean isAdminMenu = title.contains("Casas de");

        // Shift + Click = Mudar ícone
        if (event.isShiftClick()) {
            editingHome.put(player.getUniqueId(), homeName);
            openIconSelector(player, homeName);
            return;
        }

        // Q (Drop) = Deletar
        if (event.getClick().toString().contains("DROP")) {
            homeManager.deleteHome(player, homeName);
            Bukkit.getScheduler().runTaskLater(PaperHomePlugin.getInstance(), () -> {
                player.closeInventory();
                player.performCommand("casas");
            }, 5L);
            return;
        }

        // Click normal = Teleportar
        if (isAdminMenu) {
            // Extrai o nome do jogador do título
            String targetName = title.replace("§8§lCasas de §e", "");
            Player target = Bukkit.getPlayer(targetName);
            if (target != null) {
                HomeData home = homeManager.getHome(target.getUniqueId(), homeName);
                if (home != null) {
                    player.teleport(home.getLocation());
                    player.sendMessage("§a§l✔ §aTeleportado para home §e" + home.getDisplayName() + " §ade §e" + targetName + "§a!");
                }
            }
        } else {
            homeManager.teleportToHome(player, homeName);
        }

        player.closeInventory();
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getView().getTitle().equals("§8§lSelecionar Ícone")) {
            editingHome.remove(event.getPlayer().getUniqueId());
        }
    }

    private void openIconSelector(Player player, String homeName) {
        Inventory menu = Bukkit.createInventory(null, 27, "§8§lSelecionar Ícone");

        // Ícones disponíveis
        Material[] icons = {
            Material.DIRT,           // Padrão - Terra
            Material.WHITE_BED,      // Cama
            Material.STONE,          // Pedra
            Material.SAND,           // Areia
            Material.GRASS_BLOCK,    // Grama
            Material.OAK_LOG,        // Madeira
            Material.BRICKS,         // Tijolos
            Material.DIAMOND_BLOCK,  // Diamante
            Material.GOLD_BLOCK,     // Ouro
            Material.NETHERITE_BLOCK,// Netherite
            Material.RED_WOOL,       // Vermelho
            Material.BLUE_WOOL,      // Azul
            Material.GREEN_WOOL,     // Verde
            Material.YELLOW_WOOL,    // Amarelo
            Material.PURPLE_WOOL,    // Roxo
            Material.ENDER_CHEST,    // Ender Chest
            Material.BEACON,         // Beacon
            Material.CRAFTING_TABLE  // Crafting
        };

        String[] names = {
            "§e§lTerra §7(Padrão)",
            "§e§lCama",
            "§e§lPedra",
            "§e§lAreia",
            "§e§lGrama",
            "§e§lMadeira",
            "§e§lTijolos",
            "§e§lBloco de Diamante",
            "§e§lBloco de Ouro",
            "§e§lBloco de Netherite",
            "§e§lVermelho",
            "§e§lAzul",
            "§e§lVerde",
            "§e§lAmarelo",
            "§e§lRoxo",
            "§e§lEnder Chest",
            "§e§lBeacon",
            "§e§lCrafting Table"
        };

        for (int i = 0; i < icons.length && i < 27; i++) {
            ItemStack item = new ItemStack(icons[i]);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(names[i]);
            meta.setLore(Arrays.asList("", "§e§l➜ Clique §7para selecionar este ícone"));
            item.setItemMeta(meta);
            menu.setItem(i, item);
        }

        // Preencher restante com vidro
        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.setDisplayName(" ");
        filler.setItemMeta(fillerMeta);

        for (int i = icons.length; i < 27; i++) {
            menu.setItem(i, filler);
        }

        player.openInventory(menu);
    }

    private String formatMaterialName(String materialName) {
        String[] parts = materialName.toLowerCase().split("_");
        StringBuilder result = new StringBuilder();
        for (String part : parts) {
            result.append(part.substring(0, 1).toUpperCase()).append(part.substring(1)).append(" ");
        }
        return result.toString().trim();
    }
}
