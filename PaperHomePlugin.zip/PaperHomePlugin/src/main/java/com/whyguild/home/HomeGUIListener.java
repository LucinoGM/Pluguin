package com.whyguild.home;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HomeGUIListener implements Listener {

    private final HomeManager homeManager;
    private final Map<UUID, String> guiOwners = new HashMap<>();

    public HomeGUIListener(HomeManager homeManager) {
        this.homeManager = homeManager;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        String title = event.getView().getTitle();
        if (!title.startsWith("§8Casas de §e")) return;

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.BLACK_STAINED_GLASS_PANE) return;
        if (!clicked.hasItemMeta()) return;

        ItemMeta meta = clicked.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) return;

        String homeName = meta.getDisplayName().replace("§a§l", "").replace("§r", "");
        String ownerName = title.replace("§8Casas de §e", "");

        // Verificar se é admin vendo casa de outro
        boolean isAdminView = !ownerName.equals(player.getName());

        if (event.isShiftClick()) {
            // Shift + Click = Teleportar
            if (isAdminView) {
                // Admin teleportando para casa de outro player
                UUID targetUUID = homeManager.getPlayerUUID(ownerName);
                if (targetUUID != null) {
                    HomeManager.HomeData home = homeManager.getHomes(targetUUID).get(homeName.toLowerCase());
                    if (home != null) {
                        player.teleport(home.getLocation());
                        player.sendMessage("§a✅ Teleportado para a casa '§e" + homeName + "§a' de §e" + ownerName + "§a!");
                        Bukkit.getScheduler().runTask(PaperHomePlugin.getInstance(), player::closeInventory);
                    }
                }
            } else {
                // Próprio player teleportando
                HomeManager.HomeData home = homeManager.getHome(player, homeName);
                if (home != null) {
                    int delay = PaperHomePlugin.getInstance().getConfig().getInt("teleport-delay", 3);
                    if (delay > 0) {
                        player.sendMessage("§eTeleportando em §c" + delay + " §esegundos... Não se mova!");
                        Location startLoc = player.getLocation().clone();
                        Bukkit.getScheduler().runTaskLater(PaperHomePlugin.getInstance(), () -> {
                            if (player.isOnline() && player.getLocation().distance(startLoc) < 1.0) {
                                player.teleport(home.getLocation());
                                player.sendMessage("§a✅ Teleportado para '§e" + homeName + "§a'!");
                            } else if (player.isOnline()) {
                                player.sendMessage("§cTeleporte cancelado! Você se moveu.");
                            }
                        }, delay * 20L);
                    } else {
                        player.teleport(home.getLocation());
                        player.sendMessage("§a✅ Teleportado para '§e" + homeName + "§a'!");
                    }
                    Bukkit.getScheduler().runTask(PaperHomePlugin.getInstance(), player::closeInventory);
                }
            }
        } else if (event.isRightClick() && !isAdminView) {
            // Click Direito = Deletar (só próprio player)
            if (homeManager.deleteHome(player, homeName)) {
                player.sendMessage("§c✖ Casa '§e" + homeName + "§c' deletada!");
                Bukkit.getScheduler().runTask(PaperHomePlugin.getInstance(), player::closeInventory);

                // Reabrir GUI atualizada
                Bukkit.getScheduler().runTaskLater(PaperHomePlugin.getInstance(), () -> {
                    if (player.isOnline()) {
                        player.performCommand("casas");
                    }
                }, 5L);
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player) {
            guiOwners.remove(event.getPlayer().getUniqueId());
        }
    }
}