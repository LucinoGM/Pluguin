package com.whyguild.home;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CasasAdminCommand implements CommandExecutor {

    private final HomeManager homeManager;

    public CasasAdminCommand(HomeManager homeManager) {
        this.homeManager = homeManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c§l✖ §cApenas jogadores podem usar este comando!");
            return true;
        }

        Player player = (Player) sender;

        if (!player.hasPermission("homeplugin.admin")) {
            player.sendMessage("§c§l✖ §cVocê não tem permissão para usar este comando!");
            return true;
        }

        if (args.length < 1) {
            player.sendMessage("");
            player.sendMessage("§6§l╔════════════════════════════╗");
            player.sendMessage("§6§l║    §e§lADMIN - CASAS      §6§l║");
            player.sendMessage("§6§l╠════════════════════════════╣");
            player.sendMessage("§e /casasadmin <jogador> §7- Ver homes do jogador");
            player.sendMessage("§e /casas <jogador> §7- Atalho para ver homes");
            player.sendMessage("§6§l╚════════════════════════════╝");
            player.sendMessage("");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage("§c§l✖ §cJogador §e" + args[0] + " §cnão encontrado!");
            return true;
        }

        // Abre o menu de homes do jogador
        CasasCommand casasCmd = new CasasCommand(homeManager);
        casasCmd.openHomesMenu(player, target.getUniqueId(), target.getName(), true);

        return true;
    }
}
