package com.whyguild.home;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class CasasCommand implements CommandExecutor {

    private final HomeManager homeManager;

    public CasasCommand(HomeManager homeManager) {
        this.homeManager = homeManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c§l✖ §cApenas jogadores podem usar este comando!");
            return true;
        }

        Player player = (Player) sender;

        // Se for admin e passar nome de jogador, mostra homes dele
        if (args.length >= 1 && player.hasPermission("homeplugin.admin")) {
            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                player.sendMessage("§c§l✖ §cJogador §e" + args[0] + " §cnão encontrado ou offline!");
                return true;
            }
            openHomesMenu(player, target.getUniqueId(), target.getName(), true);
            return true;
        }

        // Abre menu próprio
        openHomesMenu(player, player.getUniqueId(), player.getName(), false);
        return true;
    }

    public void openHomesMenu(Player viewer, UUID targetUUID, String targetName, boolean isAdmin) {
        List<HomeData> homes = homeManager.getPlayerHomes(targetUUID);

        if (homes.isEmpty()) {
            if (isAdmin) {
                viewer.sendMessage("§c§l✖ §e" + targetName + " §cnão tem nenhuma home salva!");
            } else {
                viewer.sendMessage("§c§l✖ §cVocê não tem nenhuma home salva!");
                viewer.sendMessage("§7   Use §f/setarcasa <nome> §7para criar uma.");
            }
            return;
        }

        int size = ((homes.size() / 9) + 1) * 9;
        if (size > 54) size = 54;
        if (size < 27) size = 27;

        String title = isAdmin 
            ? "§8§lCasas de §e" + targetName 
            : "§8§lSuas Casas §7(" + homes.size() + "/" + homeManager.getMaxHomes() + ")";

        Inventory menu = Bukkit.createInventory(null, size, title);

        for (int i = 0; i < homes.size() && i < size; i++) {
            HomeData home = homes.get(i);
            ItemStack item = createHomeItem(home, isAdmin);
            menu.setItem(i, item);
        }

        // Preencher slots vazios com vidro preto
        ItemStack filler = createFiller();
        for (int i = homes.size(); i < size; i++) {
            menu.setItem(i, filler);
        }

        viewer.openInventory(menu);
    }

    private ItemStack createHomeItem(HomeData home, boolean isAdmin) {
        Material material = getMaterialFromIcon(home.getIcon());
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName("§e§l" + home.getDisplayName());

        String worldName = home.getLocation().getWorld() != null 
            ? home.getLocation().getWorld().getName() 
            : "Desconhecido";

        List<String> lore = Arrays.asList(
            "",
            "§7Mundo: §f" + worldName,
            "§7X: §f" + String.format("%.1f", home.getLocation().getX()),
            "§7Y: §f" + String.format("%.1f", home.getLocation().getY()),
            "§7Z: §f" + String.format("%.1f", home.getLocation().getZ()),
            "",
            "§e§l➜ Clique §7para teleportar",
            "§b§l➜ Shift+Clique §7para mudar ícone",
            "§c§l➜ Q (Drop) §7para deletar"
        );

        meta.setLore(lore);
        item.setItemMeta(meta);

        return item;
    }

    private ItemStack createFiller() {
        ItemStack item = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(" ");
        item.setItemMeta(meta);
        return item;
    }

    private Material getMaterialFromIcon(String icon) {
        try {
            return Material.valueOf(icon);
        } catch (IllegalArgumentException e) {
            return Material.DIRT;
        }
    }
}
