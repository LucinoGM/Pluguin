package com.whyguild.home;

import org.bukkit.plugin.java.JavaPlugin;

public class PaperHomePlugin extends JavaPlugin {

    private static PaperHomePlugin instance;
    private DatabaseManager database;
    private HomeManager homeManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        // Inicializa banco de dados SQLite
        database = new DatabaseManager(this);
        database.init();

        homeManager = new HomeManager(database);

        // Registra comandos
        getCommand("setarcasa").setExecutor(new SetarCasaCommand(homeManager));
        getCommand("casa").setExecutor(new CasaCommand(homeManager));
        getCommand("casas").setExecutor(new CasasCommand(homeManager));
        getCommand("delcasa").setExecutor(new DelCasaCommand(homeManager));
        getCommand("casasadmin").setExecutor(new CasasAdminCommand(homeManager));

        // Registra listener do menu
        getServer().getPluginManager().registerEvents(new MenuListener(homeManager), this);

        getLogger().info("§a[PaperHomePlugin] Plugin de Homes ativado com sucesso!");
        getLogger().info("§a[PaperHomePlugin] Versão 1.0.0 - by whyguild");
    }

    @Override
    public void onDisable() {
        if (database != null) {
            database.close();
        }
        getLogger().info("§c[PaperHomePlugin] Plugin desativado.");
    }

    public static PaperHomePlugin getInstance() {
        return instance;
    }

    public HomeManager getHomeManager() {
        return homeManager;
    }
}
