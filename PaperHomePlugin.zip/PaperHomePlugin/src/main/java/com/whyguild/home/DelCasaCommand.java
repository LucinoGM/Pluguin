package com.whyguild.home;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DelCasaCommand implements CommandExecutor {

    private final HomeManager homeManager;

    public DelCasaCommand(HomeManager homeManager) {
        this.homeManager = homeManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c§l✖ §cApenas jogadores podem usar este comando!");
            return true;
        }

        Player player = (Player) sender;

        if (args.length < 1) {
            player.sendMessage("");
            player.sendMessage("§6§l╔════════════════════════════╗");
            player.sendMessage("§6§l║     §e§lDELETAR CASA      §6§l║");
            player.sendMessage("§6§l╠════════════════════════════╣");
            player.sendMessage("§e Uso: §f/delcasa <nome>");
            player.sendMessage("§e Exemplo: §f/delcasa minha_casa");
            player.sendMessage("§6§l╚════════════════════════════╝");
            player.sendMessage("");
            return true;
        }

        String homeName = args[0];
        homeManager.deleteHome(player, homeName);
        return true;
    }
}
