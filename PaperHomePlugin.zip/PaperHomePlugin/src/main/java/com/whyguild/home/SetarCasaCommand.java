package com.whyguild.home;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetarCasaCommand implements CommandExecutor {

    private final HomeManager homeManager;

    public SetarCasaCommand(HomeManager homeManager) {
        this.homeManager = homeManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c§l✖ §cApenas jogadores podem usar este comando!");
            return true;
        }

        Player player = (Player) sender;

        if (args.length < 1) {
            player.sendMessage("");
            player.sendMessage("§6§l╔════════════════════════════╗");
            player.sendMessage("§6§l║      §e§lSETAR CASA       §6§l║");
            player.sendMessage("§6§l╠════════════════════════════╣");
            player.sendMessage("§e Uso: §f/setarcasa <nome>");
            player.sendMessage("§e Exemplo: §f/setarcasa minha_casa");
            player.sendMessage("§7 Máximo de homes: §f" + homeManager.getMaxHomes());
            player.sendMessage("§6§l╚════════════════════════════╝");
            player.sendMessage("");
            return true;
        }

        String homeName = args[0];
        homeManager.setHome(player, homeName);
        return true;
    }
}
