package com.whyguild.home;

import org.bukkit.Location;

import java.util.UUID;

public class HomeData {

    private final UUID playerUUID;
    private final String playerName;
    private final String homeName;
    private final Location location;
    private String icon;

    public HomeData(UUID playerUUID, String playerName, String homeName, Location location, String icon) {
        this.playerUUID = playerUUID;
        this.playerName = playerName;
        this.homeName = homeName;
        this.location = location;
        this.icon = icon;
    }

    public UUID getPlayerUUID() { return playerUUID; }
    public String getPlayerName() { return playerName; }
    public String getHomeName() { return homeName; }
    public Location getLocation() { return location; }
    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    public String getDisplayName() {
        return homeName.substring(0, 1).toUpperCase() + homeName.substring(1);
    }
}
