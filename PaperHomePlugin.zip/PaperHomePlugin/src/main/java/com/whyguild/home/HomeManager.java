package com.whyguild.home;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;

public class HomeManager {

    private final DatabaseManager database;
    private static final int MAX_HOMES_DEFAULT = 5;

    public HomeManager(DatabaseManager database) {
        this.database = database;
    }

    public boolean setHome(Player player, String homeName) {
        if (!player.hasPermission("homeplugin.unlimited")) {
            int currentHomes = database.getHomeCount(player.getUniqueId());
            if (currentHomes >= MAX_HOMES_DEFAULT) {
                player.sendMessage("§c§l✖ §cVocê atingiu o limite de " + MAX_HOMES_DEFAULT + " homes!");
                return false;
            }
        }

        if (homeName.length() > 16) {
            player.sendMessage("§c§l✖ §cO nome da home deve ter no máximo 16 caracteres!");
            return false;
        }

        if (!homeName.matches("[a-zA-Z0-9_]+")) {
            player.sendMessage("§c§l✖ §cUse apenas letras, números e underline no nome!");
            return false;
        }

        Location location = player.getLocation();
        database.saveHome(player.getUniqueId(), player.getName(), homeName, location, "DIRT");

        player.sendMessage("§a§l✔ §aHome §f'§e" + homeName + "§f' §asalva com sucesso!");
        player.sendMessage("§7   Mundo: §f" + location.getWorld().getName() + 
                " §7| X: §f" + String.format("%.1f", location.getX()) +
                " §7| Y: §f" + String.format("%.1f", location.getY()) +
                " §7| Z: §f" + String.format("%.1f", location.getZ()));
        return true;
    }

    public boolean teleportToHome(Player player, String homeName) {
        HomeData home = database.getHome(player.getUniqueId(), homeName);

        if (home == null) {
            player.sendMessage("§c§l✖ §cHome §f'§e" + homeName + "§f' §cnão encontrada!");
            player.sendMessage("§7   Use §f/casas §7para ver suas homes.");
            return false;
        }

        Location loc = home.getLocation();
        if (loc.getWorld() == null) {
            player.sendMessage("§c§l✖ §cO mundo desta home não existe mais!");
            return false;
        }

        player.teleport(loc);
        player.sendMessage("§a§l✔ §aTeleportado para §e" + home.getDisplayName() + "§a!");
        return true;
    }

    public boolean deleteHome(Player player, String homeName) {
        HomeData home = database.getHome(player.getUniqueId(), homeName);

        if (home == null) {
            player.sendMessage("§c§l✖ §cHome §f'§e" + homeName + "§f' §cnão encontrada!");
            return false;
        }

        database.deleteHome(player.getUniqueId(), homeName);
        player.sendMessage("§a§l✔ §aHome §e" + home.getDisplayName() + " §aremovida com sucesso!");
        return true;
    }

    public List<HomeData> getPlayerHomes(UUID playerUUID) {
        return database.getPlayerHomes(playerUUID);
    }

    public void updateHomeIcon(UUID playerUUID, String homeName, String icon) {
        database.updateHomeIcon(playerUUID, homeName, icon);
    }

    public HomeData getHome(UUID playerUUID, String homeName) {
        return database.getHome(playerUUID, homeName);
    }

    public int getHomeCount(UUID playerUUID) {
        return database.getHomeCount(playerUUID);
    }

    public int getMaxHomes() {
        return MAX_HOMES_DEFAULT;
    }
}
