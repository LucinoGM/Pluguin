package com.exemplo.arvoretotal;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.Leaves;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class ArvoreTotal extends JavaPlugin implements Listener {

    private static final int MAX_TRONCOS = 400;
    private static final boolean EXIGE_MACHADO = true;
    private static final boolean AGACHAR_DESATIVA = true;

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("ArvoreTotal ativado!");
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void aoQuebrar(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Block origem = e.getBlock();

        if (!ehTronco(origem.getType())) return;
        if (!p.hasPermission("arvoretotal.use")) return;
        if (p.getGameMode() != GameMode.SURVIVAL) return;
        if (AGACHAR_DESATIVA && p.isSneaking()) return;

        ItemStack ferramenta = p.getInventory().getItemInMainHand();
        if (EXIGE_MACHADO && !ferramenta.getType().name().endsWith("_AXE")) return;

        Set<Block> troncos = coletarTroncos(origem);
        if (troncos.size() <= 1) return;
        if (!ehArvoreNatural(troncos)) return; // não destrói casas de madeira

        // Base da árvore (para replantar)
        int minY = troncos.stream().mapToInt(Block::getY).min().orElse(origem.getY());
        List<Block> bases = new ArrayList<>();
        for (Block b : troncos) {
            if (b.getY() == minY && Tag.DIRT.isTagged(b.getRelative(BlockFace.DOWN).getType())) {
                bases.add(b);
            }
        }
        Material muda = Material.matchMaterial(
                origem.getType().name().replace("_LOG", "_SAPLING"));

        // Quebra o resto dos troncos, gastando durabilidade
        for (Block b : troncos) {
            if (b.equals(origem)) continue;
            if (!gastarDurabilidade(ferramenta)) break;
            b.breakNaturally(ferramenta);
        }

        // Replanta 1 tick depois (o tronco original já foi removido)
        if (muda != null && !bases.isEmpty()) {
            Bukkit.getScheduler().runTask(this, () -> {
                for (Block b : bases) {
                    if (b.getType().isAir()) {
                        b.setType(muda);
                    }
                }
            });
        }
    }

    private boolean ehTronco(Material m) {
        String n = m.name();
        return n.endsWith("_LOG") && !n.startsWith("STRIPPED_");
    }

    private Set<Block> coletarTroncos(Block inicio) {
        Set<Block> achados = new LinkedHashSet<>();
        Deque<Block> fila = new ArrayDeque<>();
        Material tipo = inicio.getType();
        achados.add(inicio);
        fila.add(inicio);

        while (!fila.isEmpty() && achados.size() < MAX_TRONCOS) {
            Block atual = fila.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block viz = atual.getRelative(dx, dy, dz);
                        if (viz.getType() == tipo && achados.add(viz)) {
                            fila.add(viz);
                            if (achados.size() >= MAX_TRONCOS) return achados;
                        }
                    }
                }
            }
        }
        return achados;
    }

    /** Árvore natural = algum tronco encostado em folhas não colocadas por jogador. */
    private boolean ehArvoreNatural(Set<Block> troncos) {
        for (Block b : troncos) {
            for (BlockFace f : new BlockFace[]{BlockFace.UP, BlockFace.NORTH, BlockFace.SOUTH,
                    BlockFace.EAST, BlockFace.WEST, BlockFace.DOWN}) {
                Block viz = b.getRelative(f);
                if (Tag.LEAVES.isTagged(viz.getType())
                        && viz.getBlockData() instanceof Leaves folha
                        && !folha.isPersistent()) {
                    return true;
                }
            }
        }
        return false;
    }

    /** Retorna false se a ferramenta quebraria (para antes disso). */
    private boolean gastarDurabilidade(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (!(meta instanceof Damageable d)) return true;
        int max = item.getType().getMaxDurability();
        if (max <= 0) return true;
        int novo = d.getDamage() + 1;
        if (novo >= max) return false;
        d.setDamage(novo);
        item.setItemMeta(d);
        return true;
    }
}
