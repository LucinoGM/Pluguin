package com.exemplo.veinminer;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.Set;

public class VeinMiner extends JavaPlugin implements Listener {

    private static final int MAX_BLOCOS = 128;
    private static final boolean EXIGE_PICARETA = true;
    private static final boolean AGACHAR_DESATIVA = true;

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("VeinMiner ativado!");
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void aoQuebrar(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Block origem = e.getBlock();

        if (!ehMinerio(origem.getType())) return;
        if (!p.hasPermission("veinminer.use")) return;
        if (p.getGameMode() != GameMode.SURVIVAL) return;
        if (AGACHAR_DESATIVA && p.isSneaking()) return;

        ItemStack ferramenta = p.getInventory().getItemInMainHand();
        if (EXIGE_PICARETA && !ferramenta.getType().name().endsWith("_PICKAXE")) return;

        Set<Block> veia = coletarVeia(origem);
        if (veia.size() <= 1) return;

        for (Block b : veia) {
            if (b.equals(origem)) continue; // o original quebra normalmente
            if (!gastarDurabilidade(ferramenta)) break;
            b.breakNaturally(ferramenta, true, true); // com drops, efeito e XP
        }
    }

    private boolean ehMinerio(Material m) {
        String n = m.name();
        return n.endsWith("_ORE") || m == Material.ANCIENT_DEBRIS;
    }

    /** Trata minério normal e "deepslate" como o mesmo tipo (ex: DIAMOND_ORE = DEEPSLATE_DIAMOND_ORE). */
    private String grupo(Material m) {
        return m.name().replace("DEEPSLATE_", "");
    }

    private Set<Block> coletarVeia(Block inicio) {
        String g = grupo(inicio.getType());
        Set<Block> achados = new LinkedHashSet<>();
        Deque<Block> fila = new ArrayDeque<>();
        achados.add(inicio);
        fila.add(inicio);

        while (!fila.isEmpty() && achados.size() < MAX_BLOCOS) {
            Block atual = fila.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block viz = atual.getRelative(dx, dy, dz);
                        if (ehMinerio(viz.getType()) && grupo(viz.getType()).equals(g)
                                && achados.add(viz)) {
                            fila.add(viz);
                            if (achados.size() >= MAX_BLOCOS) return achados;
                        }
                    }
                }
            }
        }
        return achados;
    }

    /** Retorna false se a ferramenta quebraria (para antes disso). */
    private boolean gastarDurabilidade(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (!(meta instanceof Damageable d)) return true;
        int max = item.getType().getMaxDurability();
        if (max <= 0) return true;
        int novo = d.getDamage() + 1;
        if (novo >= max) return false;
        d.setDamage(novo);
        item.setItemMeta(d);
        return true;
    }
}
