package com.exemplo.survivalplus;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.Set;

/** Quebra a veia inteira de minério. Cada bloco extra conta no /tops. */
public class VeinMiner implements Listener {

    private static final int MAX_BLOCOS = 128;
    private static final boolean EXIGE_PICARETA = true;
    private static final boolean AGACHAR_DESATIVA = true;

    private final Tops tops;

    public VeinMiner(Tops tops) {
        this.tops = tops;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void aoQuebrar(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Block origem = e.getBlock();

        if (!ehMinerio(origem.getType())) return;
        if (p.getGameMode() != GameMode.SURVIVAL) return;
        if (AGACHAR_DESATIVA && p.isSneaking()) return;

        ItemStack ferramenta = p.getInventory().getItemInMainHand();
        if (EXIGE_PICARETA && !ferramenta.getType().name().endsWith("_PICKAXE")) return;

        Set<Block> veia = coletarVeia(origem);
        if (veia.size() <= 1) return;

        for (Block b : veia) {
            if (b.equals(origem)) continue; // o original quebra normalmente (e conta no top)
            if (!gastarDurabilidade(ferramenta)) break;
            Material tipo = b.getType();
            b.breakNaturally(ferramenta, true, true);
            tops.contarBloco(p, tipo); // conta cada bloco da veia
        }
    }

    private boolean ehMinerio(Material m) {
        return m.name().endsWith("_ORE") || m == Material.ANCIENT_DEBRIS;
    }

    private String grupo(Material m) {
        return m.name().replace("DEEPSLATE_", "");
    }

    private Set<Block> coletarVeia(Block inicio) {
        String g = grupo(inicio.getType());
        Set<Block> achados = new LinkedHashSet<>();
        Deque<Block> fila = new ArrayDeque<>();
        achados.add(inicio);
        fila.add(inicio);

        while (!fila.isEmpty() && achados.size() < MAX_BLOCOS) {
            Block atual = fila.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block viz = atual.getRelative(dx, dy, dz);
                        if (ehMinerio(viz.getType()) && grupo(viz.getType()).equals(g) && achados.add(viz)) {
                            fila.add(viz);
                            if (achados.size() >= MAX_BLOCOS) return achados;
                        }
                    }
                }
            }
        }
        return achados;
    }

    private boolean gastarDurabilidade(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (!(meta instanceof Damageable d)) return true;
        int max = item.getType().getMaxDurability();
        if (max <= 0) return true;
        int novo = d.getDamage() + 1;
        if (novo >= max) return false;
        d.setDamage(novo);
        item.setItemMeta(d);
        return true;
    }
}
