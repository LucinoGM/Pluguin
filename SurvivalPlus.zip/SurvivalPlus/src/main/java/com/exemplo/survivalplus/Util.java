package com.exemplo.survivalplus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;

public final class Util {
    private Util() {}

    /** Texto colorido sem itálico (bom para nomes/lore de itens). */
    public static Component txt(String s, NamedTextColor c) {
        return Component.text(s, c).decoration(TextDecoration.ITALIC, false);
    }

    public static NamedTextColor corPorcentagem(double pct) {
        if (pct > 60) return NamedTextColor.GREEN;
        if (pct > 30) return NamedTextColor.YELLOW;
        return NamedTextColor.RED;
    }
}
