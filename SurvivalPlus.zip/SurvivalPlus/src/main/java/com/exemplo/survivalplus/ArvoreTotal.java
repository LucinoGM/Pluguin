package com.exemplo.survivalplus;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.Leaves;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Quebra a árvore inteira e replanta a muda. Cada tronco conta no /tops. */
public class ArvoreTotal implements Listener {

    private static final int MAX_TRONCOS = 400;
    private static final boolean EXIGE_MACHADO = true;
    private static final boolean AGACHAR_DESATIVA = true;

    private final SurvivalPlus plugin;
    private final Tops tops;

    public ArvoreTotal(SurvivalPlus plugin, Tops tops) {
        this.plugin = plugin;
        this.tops = tops;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void aoQuebrar(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Block origem = e.getBlock();

        if (!ehTronco(origem.getType())) return;
        if (p.getGameMode() != GameMode.SURVIVAL) return;
        if (AGACHAR_DESATIVA && p.isSneaking()) return;

        ItemStack ferramenta = p.getInventory().getItemInMainHand();
        if (EXIGE_MACHADO && !ferramenta.getType().name().endsWith("_AXE")) return;

        Set<Block> troncos = coletarTroncos(origem);
        if (troncos.size() <= 1) return;
        if (!ehArvoreNatural(troncos)) return; // não destrói casas de madeira

        int minY = troncos.stream().mapToInt(Block::getY).min().orElse(origem.getY());
        List<Block> bases = new ArrayList<>();
        for (Block b : troncos) {
            if (b.getY() == minY && Tag.DIRT.isTagged(b.getRelative(BlockFace.DOWN).getType())) {
                bases.add(b);
            }
        }
        Material muda = Material.matchMaterial(origem.getType().name().replace("_LOG", "_SAPLING"));

        for (Block b : troncos) {
            if (b.equals(origem)) continue; // o original conta pelo evento normal
            if (!gastarDurabilidade(ferramenta)) break;
            Material tipo = b.getType();
            b.breakNaturally(ferramenta);
            tops.contarBloco(p, tipo); // conta cada tronco
        }

        if (muda != null && !bases.isEmpty()) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                for (Block b : bases) {
                    if (b.getType().isAir()) b.setType(muda);
                }
            });
        }
    }

    private boolean ehTronco(Material m) {
        String n = m.name();
        return n.endsWith("_LOG") && !n.startsWith("STRIPPED_");
    }

    private Set<Block> coletarTroncos(Block inicio) {
        Set<Block> achados = new LinkedHashSet<>();
        Deque<Block> fila = new ArrayDeque<>();
        Material tipo = inicio.getType();
        achados.add(inicio);
        fila.add(inicio);

        while (!fila.isEmpty() && achados.size() < MAX_TRONCOS) {
            Block atual = fila.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block viz = atual.getRelative(dx, dy, dz);
                        if (viz.getType() == tipo && achados.add(viz)) {
                            fila.add(viz);
                            if (achados.size() >= MAX_TRONCOS) return achados;
                        }
                    }
                }
            }
        }
        return achados;
    }

    private boolean ehArvoreNatural(Set<Block> troncos) {
        for (Block b : troncos) {
            for (BlockFace f : new BlockFace[]{BlockFace.UP, BlockFace.NORTH, BlockFace.SOUTH,
                    BlockFace.EAST, BlockFace.WEST, BlockFace.DOWN}) {
                Block viz = b.getRelative(f);
                if (Tag.LEAVES.isTagged(viz.getType())
                        && viz.getBlockData() instanceof Leaves folha
                        && !folha.isPersistent()) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean gastarDurabilidade(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (!(meta instanceof Damageable d)) return true;
        int max = item.getType().getMaxDurability();
        if (max <= 0) return true;
        int novo = d.getDamage() + 1;
        if (novo >= max) return false;
        d.setDamage(novo);
        item.setItemMeta(d);
        return true;
    }
}
