package com.exemplo.survivalplus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Wither;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MobHealth implements Listener {

    private static final long TICKS_VISIVEL = 80L; // 4 segundos

    private static class Track {
        LivingEntity entidade;
        Component nomeOriginal;
        boolean visivelOriginal;
        BukkitTask tarefa;
    }

    private final SurvivalPlus plugin;
    private final Map<UUID, Track> tracks = new HashMap<>();

    public MobHealth(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void aoDano(EntityDamageByEntityEvent e) {
        Player atacante = null;
        if (e.getDamager() instanceof Player direto) {
            atacante = direto;
        } else if (e.getDamager() instanceof Projectile proj && proj.getShooter() instanceof Player atirador) {
            atacante = atirador;
        }
        if (atacante == null) return;
        if (!(e.getEntity() instanceof LivingEntity alvo)) return;
        if (alvo instanceof ArmorStand || alvo instanceof EnderDragon || alvo instanceof Wither) return;

        Player quem = atacante;
        // a vida só é atualizada depois do evento
        Bukkit.getScheduler().runTask(plugin, () -> mostrar(quem, alvo));
    }

    private void mostrar(Player atacante, LivingEntity alvo) {
        if (!alvo.isValid() || alvo.isDead()) return;

        double vida = alvo.getHealth();
        AttributeInstance attr = alvo.getAttribute(Attribute.MAX_HEALTH);
        double max = attr != null ? attr.getValue() : vida;
        double pct = max > 0 ? 100.0 * vida / max : 0;

        Component texto = Component.text("❤ " + (int) Math.ceil(vida) + "/" + (int) Math.ceil(max),
                Util.corPorcentagem(pct));

        // jogadores não têm nome alterável: mostra na barra de ação do atacante
        if (alvo instanceof Player alvoJogador) {
            atacante.sendActionBar(Component.text(alvoJogador.getName() + " ", NamedTextColor.WHITE).append(texto));
            return;
        }

        Track tr = tracks.get(alvo.getUniqueId());
        if (tr == null) {
            tr = new Track();
            tr.entidade = alvo;
            tr.nomeOriginal = alvo.customName();
            tr.visivelOriginal = alvo.isCustomNameVisible();
            tracks.put(alvo.getUniqueId(), tr);
        } else if (tr.tarefa != null) {
            tr.tarefa.cancel();
        }

        alvo.customName(texto);
        alvo.setCustomNameVisible(true);
        UUID id = alvo.getUniqueId();
        tr.tarefa = Bukkit.getScheduler().runTaskLater(plugin, () -> restaurar(id), TICKS_VISIVEL);
    }

    private void restaurar(UUID id) {
        Track tr = tracks.remove(id);
        if (tr == null) return;
        if (tr.tarefa != null) tr.tarefa.cancel();
        if (tr.entidade != null && tr.entidade.isValid()) {
            tr.entidade.customName(tr.nomeOriginal);
            tr.entidade.setCustomNameVisible(tr.visivelOriginal);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void aoMorrer(EntityDeathEvent e) {
        restaurar(e.getEntity().getUniqueId());
    }

    public void restaurarTodos() {
        for (UUID id : new ArrayList<>(tracks.keySet())) restaurar(id);
    }
}
