package com.exemplo.survivalplus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class Tops implements Listener {

    enum Cat {
        BLOCOS("Blocos quebrados", Material.DIAMOND_PICKAXE),
        TEMPO("Tempo online", Material.CLOCK),
        MOBS("Mobs mortos", Material.IRON_SWORD),
        MORTES("Mortes", Material.SKELETON_SKULL),
        MINERIOS("Minérios quebrados", Material.DIAMOND_ORE),
        DISTANCIA("Distância andada", Material.LEATHER_BOOTS),
        DANO("Dano causado", Material.DIAMOND_SWORD);

        final String nome;
        final Material icone;

        Cat(String nome, Material icone) {
            this.nome = nome;
            this.icone = icone;
        }
    }

    static class Stats {
        String nome = "?";
        long blocos, tempo, mobs, mortes, minerios; // tempo em segundos
        double distancia, dano;
    }

    /** cat == null: menu principal; senão: top 10 da categoria. */
    static class MenuHolder implements InventoryHolder {
        final Cat cat;
        Inventory inv;

        MenuHolder(Cat cat) {
            this.cat = cat;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private static final int[] SLOTS_TOP = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24};

    private final SurvivalPlus plugin;
    private final File file;
    private final Map<UUID, Stats> dados = new HashMap<>();

    public Tops(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "stats.yml");
        carregar();

        // tempo online: soma 10s a cada 10s para quem está no servidor
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) stats(p).tempo += 10;
        }, 200L, 200L);
        // salva a cada 5 minutos
        Bukkit.getScheduler().runTaskTimer(plugin, this::save, 6000L, 6000L);
    }

    // ---------------- dados ----------------

    private Stats stats(UUID id, String nome) {
        Stats s = dados.computeIfAbsent(id, k -> new Stats());
        if (nome != null) s.nome = nome;
        return s;
    }

    private Stats stats(Player p) {
        return stats(p.getUniqueId(), p.getName());
    }

    private void carregar() {
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection s = c.getConfigurationSection("players");
        if (s == null) return;
        for (String k : s.getKeys(false)) {
            ConfigurationSection t = s.getConfigurationSection(k);
            if (t == null) continue;
            try {
                Stats st = new Stats();
                st.nome = t.getString("nome", "?");
                st.blocos = t.getLong("blocos");
                st.tempo = t.getLong("tempo");
                st.mobs = t.getLong("mobs");
                st.mortes = t.getLong("mortes");
                st.minerios = t.getLong("minerios");
                st.distancia = t.getDouble("distancia");
                st.dano = t.getDouble("dano");
                dados.put(UUID.fromString(k), st);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    public void save() {
        YamlConfiguration c = new YamlConfiguration();
        for (Map.Entry<UUID, Stats> en : dados.entrySet()) {
            String b = "players." + en.getKey();
            Stats s = en.getValue();
            c.set(b + ".nome", s.nome);
            c.set(b + ".blocos", s.blocos);
            c.set(b + ".tempo", s.tempo);
            c.set(b + ".mobs", s.mobs);
            c.set(b + ".mortes", s.mortes);
            c.set(b + ".minerios", s.minerios);
            c.set(b + ".distancia", s.distancia);
            c.set(b + ".dano", s.dano);
        }
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Nao foi possivel salvar stats.yml: " + ex.getMessage());
        }
    }

    private double valor(Stats s, Cat c) {
        return switch (c) {
            case BLOCOS -> s.blocos;
            case TEMPO -> s.tempo;
            case MOBS -> s.mobs;
            case MORTES -> s.mortes;
            case MINERIOS -> s.minerios;
            case DISTANCIA -> s.distancia;
            case DANO -> s.dano;
        };
    }

    private String formatar(Cat c, double v) {
        return switch (c) {
            case TEMPO -> {
                long seg = (long) v;
                yield (seg / 3600) + "h " + ((seg % 3600) / 60) + "min";
            }
            case DISTANCIA -> v >= 1000
                    ? String.format(Locale.ROOT, "%.1f km", v / 1000.0)
                    : String.format(Locale.ROOT, "%.0f blocos", v);
            case DANO -> String.format(Locale.ROOT, "%.0f", v);
            default -> String.valueOf((long) v);
        };
    }

    // ---------------- menus ----------------

    private void preencher(Inventory inv) {
        ItemStack vidro = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
        ItemMeta m = vidro.getItemMeta();
        m.displayName(Component.text(" "));
        vidro.setItemMeta(m);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, vidro);
    }

    public void abrir(Player p) {
        MenuHolder h = new MenuHolder(null);
        Inventory inv = Bukkit.createInventory(h, 27, Component.text("Tops do Servidor", NamedTextColor.DARK_PURPLE));
        h.inv = inv;
        preencher(inv);

        Stats meu = stats(p);
        Cat[] cats = Cat.values();
        for (int i = 0; i < cats.length; i++) {
            ItemStack it = new ItemStack(cats[i].icone);
            ItemMeta m = it.getItemMeta();
            m.displayName(Util.txt(cats[i].nome, NamedTextColor.LIGHT_PURPLE));
            m.lore(List.of(
                    Util.txt("Clique para ver o top 10", NamedTextColor.GRAY),
                    Util.txt("Você: " + formatar(cats[i], valor(meu, cats[i])), NamedTextColor.YELLOW)));
            m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            it.setItemMeta(m);
            inv.setItem(10 + i, it);
        }
        p.openInventory(inv);
    }

    private void abrirTop(Player p, Cat cat) {
        MenuHolder h = new MenuHolder(cat);
        Inventory inv = Bukkit.createInventory(h, 45,
                Component.text("Top 10 - " + cat.nome, NamedTextColor.DARK_PURPLE));
        h.inv = inv;
        preencher(inv);

        List<Map.Entry<UUID, Stats>> lista = new ArrayList<>();
        for (Map.Entry<UUID, Stats> en : dados.entrySet()) {
            if (valor(en.getValue(), cat) > 0) lista.add(en);
        }
        lista.sort((a, b) -> Double.compare(valor(b.getValue(), cat), valor(a.getValue(), cat)));

        for (int i = 0; i < Math.min(10, lista.size()); i++) {
            Map.Entry<UUID, Stats> en = lista.get(i);
            OfflinePlayer off = Bukkit.getOfflinePlayer(en.getKey());
            ItemStack cabeca = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) cabeca.getItemMeta();
            sm.setOwningPlayer(off);
            NamedTextColor cor = switch (i) {
                case 0 -> NamedTextColor.GOLD;
                case 1 -> NamedTextColor.WHITE;
                case 2 -> NamedTextColor.YELLOW;
                default -> NamedTextColor.LIGHT_PURPLE;
            };
            sm.displayName(Util.txt("#" + (i + 1) + " " + en.getValue().nome, cor));
            sm.lore(List.of(Util.txt(cat.nome + ": " + formatar(cat, valor(en.getValue(), cat)),
                    NamedTextColor.GRAY)));
            cabeca.setItemMeta(sm);
            inv.setItem(SLOTS_TOP[i], cabeca);
        }

        ItemStack voltar = new ItemStack(Material.ARROW);
        ItemMeta vm = voltar.getItemMeta();
        vm.displayName(Util.txt("Voltar", NamedTextColor.RED));
        voltar.setItemMeta(vm);
        inv.setItem(40, voltar);

        p.openInventory(inv);
    }

    @EventHandler
    public void aoClicar(InventoryClickEvent e) {
        Inventory topo = e.getView().getTopInventory();
        if (!(topo.getHolder() instanceof MenuHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != topo) return;
        int slot = e.getSlot();
        if (h.cat == null) {
            Cat[] cats = Cat.values();
            if (slot >= 10 && slot < 10 + cats.length) abrirTop(p, cats[slot - 10]);
        } else if (slot == 40) {
            abrir(p);
        }
    }

    @EventHandler
    public void aoArrastar(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof MenuHolder) e.setCancelled(true);
    }

    // ---------------- contagem ----------------

    @EventHandler
    public void aoEntrar(PlayerJoinEvent e) {
        stats(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void aoQuebrar(BlockBreakEvent e) {
        Stats s = stats(e.getPlayer());
        s.blocos++;
        Material m = e.getBlock().getType();
        if (m.name().endsWith("_ORE") || m == Material.ANCIENT_DEBRIS) s.minerios++;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void aoMatar(EntityDeathEvent e) {
        Player killer = e.getEntity().getKiller();
        if (killer != null && !(e.getEntity() instanceof Player)) stats(killer).mobs++;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void aoMorrer(PlayerDeathEvent e) {
        stats(e.getEntity()).mortes++;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void aoDano(EntityDamageByEntityEvent e) {
        Player atacante = null;
        if (e.getDamager() instanceof Player direto) {
            atacante = direto;
        } else if (e.getDamager() instanceof Projectile proj && proj.getShooter() instanceof Player atirador) {
            atacante = atirador;
        }
        if (atacante == null || !(e.getEntity() instanceof LivingEntity)) return;
        stats(atacante).dano += e.getFinalDamage();
    }

    @EventHandler(ignoreCancelled = true)
    public void aoMover(PlayerMoveEvent e) {
        if (e.getTo() == null) return;
        Player p = e.getPlayer();
        if (p.isGliding() || p.isFlying() || p.isInsideVehicle()) return;
        double dx = e.getTo().getX() - e.getFrom().getX();
        double dz = e.getTo().getZ() - e.getFrom().getZ();
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d > 0 && d < 8) stats(p).distancia += d; // ignora teleportes
    }
}
