package com.exemplo.survivalplus;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Iterator;

public class Harvester implements Listener {

    private final SurvivalPlus plugin;

    public Harvester(SurvivalPlus plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void aoDropar(BlockDropItemEvent e) {
        BlockState estado = e.getBlockState();
        Material tipo = estado.getType();

        Material semente = switch (tipo) {
            case WHEAT -> Material.WHEAT_SEEDS;
            case CARROTS -> Material.CARROT;
            case POTATOES -> Material.POTATO;
            case BEETROOTS -> Material.BEETROOT_SEEDS;
            case NETHER_WART -> Material.NETHER_WART;
            default -> null;
        };
        if (semente == null) return;

        // só replanta se estava madura
        if (!(estado.getBlockData() instanceof Ageable idade)) return;
        if (idade.getAge() < idade.getMaximumAge()) return;

        // usa uma semente dos próprios drops
        boolean achou = false;
        Iterator<Item> it = e.getItems().iterator();
        while (it.hasNext()) {
            Item item = it.next();
            ItemStack stack = item.getItemStack();
            if (stack.getType() == semente) {
                if (stack.getAmount() > 1) {
                    stack.setAmount(stack.getAmount() - 1);
                    item.setItemStack(stack);
                } else {
                    it.remove();
                }
                achou = true;
                break;
            }
        }
        // se não veio semente nos drops, tenta tirar do inventário do jogador
        if (!achou) {
            if (!e.getPlayer().getInventory().removeItem(new ItemStack(semente, 1)).isEmpty()) return;
        }

        Block bloco = e.getBlock();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (bloco.getType().isAir()) {
                bloco.setType(tipo);
            }
        });
    }
}
