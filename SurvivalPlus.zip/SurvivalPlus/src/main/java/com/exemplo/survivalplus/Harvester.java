package com.exemplo.survivalplus;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Harvester implements Listener {

    private final SurvivalPlus plugin;
    private final Tops tops;
    private static final long TICKS_PROTECAO = 100L; // 5 segundos
    private final Set<String> protegidas = new HashSet<>();

    public Harvester(SurvivalPlus plugin, Tops tops) {
        this.plugin = plugin;
        this.tops = tops;
    }

    private String chave(Block b) {
        return b.getWorld().getName() + ";" + b.getX() + ";" + b.getY() + ";" + b.getZ();
    }

    /**
     * A muda que acabou de ser replantada fica protegida por 5 segundos,
     * para você não quebrar sem querer ao correr segurando o botão de bater.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void protegerMuda(BlockBreakEvent e) {
        if (protegidas.contains(chave(e.getBlock()))) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void aoDropar(BlockDropItemEvent e) {
        BlockState estado = e.getBlockState();
        Material tipo = estado.getType();

        Material semente = switch (tipo) {
            case WHEAT -> Material.WHEAT_SEEDS;
            case CARROTS -> Material.CARROT;
            case POTATOES -> Material.POTATO;
            case BEETROOTS -> Material.BEETROOT_SEEDS;
            case NETHER_WART -> Material.NETHER_WART;
            default -> null;
        };
        if (semente == null) return;

        // só replanta se estava madura
        if (!(estado.getBlockData() instanceof Ageable idade)) return;
        if (idade.getAge() < idade.getMaximumAge()) return;

        tops.contarColheita(e.getPlayer()); // conta no /tops

        // usa uma semente dos próprios drops
        boolean achou = false;
        Iterator<Item> it = e.getItems().iterator();
        while (it.hasNext()) {
            Item item = it.next();
            ItemStack stack = item.getItemStack();
            if (stack.getType() == semente) {
                if (stack.getAmount() > 1) {
                    stack.setAmount(stack.getAmount() - 1);
                    item.setItemStack(stack);
                } else {
                    it.remove();
                }
                achou = true;
                break;
            }
        }
        // se não veio semente nos drops, tenta tirar do inventário do jogador
        if (!achou) {
            if (!e.getPlayer().getInventory().removeItem(new ItemStack(semente, 1)).isEmpty()) return;
        }

        Block bloco = e.getBlock();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (bloco.getType().isAir()) {
                bloco.setType(tipo);
                String chave = chave(bloco);
                protegidas.add(chave);
                Bukkit.getScheduler().runTaskLater(plugin, () -> protegidas.remove(chave), TICKS_PROTECAO);
            }
        });
    }
}
