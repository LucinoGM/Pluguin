package com.exemplo.survivalplus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class SurvivalPlus extends JavaPlugin {

    private Dba dba;
    private Tops tops;
    private Tombs tombs;
    private MobHealth mobHealth;
    private NightLuz nightLuz;

    @Override
    public void onEnable() {
        getDataFolder().mkdirs();
        dba = new Dba(this);
        tops = new Tops(this);
        tombs = new Tombs(this);
        mobHealth = new MobHealth(this);
        nightLuz = new NightLuz(this, dba);

        Bukkit.getPluginManager().registerEvents(dba, this);
        Bukkit.getPluginManager().registerEvents(tops, this);
        Bukkit.getPluginManager().registerEvents(tombs, this);
        Bukkit.getPluginManager().registerEvents(mobHealth, this);
        Bukkit.getPluginManager().registerEvents(new Harvester(this, tops), this);
        Bukkit.getPluginManager().registerEvents(new VeinMiner(tops), this);
        Bukkit.getPluginManager().registerEvents(new ArvoreTotal(this, tops), this);

        getLogger().info("SurvivalPlus ativado!");
    }

    @Override
    public void onDisable() {
        if (dba != null) dba.save();
        if (tops != null) tops.save();
        if (tombs != null) tombs.save();
        if (mobHealth != null) mobHealth.restaurarTodos();
        if (nightLuz != null) nightLuz.parar();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Apenas jogadores podem usar este comando.");
            return true;
        }
        switch (command.getName().toLowerCase()) {
            case "dba" -> dba.alternar(p);
            case "tops" -> tops.abrir(p);
            case "luz" -> nightLuz.alternar(p);
            default -> p.sendMessage(Component.text("Comando desconhecido.", NamedTextColor.RED));
        }
        return true;
    }
}
