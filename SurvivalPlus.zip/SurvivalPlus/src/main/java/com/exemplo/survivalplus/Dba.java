package com.exemplo.survivalplus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class Dba implements Listener {

    private final SurvivalPlus plugin;
    private final File file;
    private final Set<UUID> ativos = new HashSet<>();
    private final NamespacedKey avisado;

    public Dba(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "dba.yml");
        this.avisado = new NamespacedKey(plugin, "dba_avisado");
        carregar();
    }

    private void carregar() {
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        for (String s : c.getStringList("ativos")) {
            try {
                ativos.add(UUID.fromString(s));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    public void save() {
        YamlConfiguration c = new YamlConfiguration();
        List<String> lista = new ArrayList<>();
        for (UUID u : ativos) lista.add(u.toString());
        c.set("ativos", lista);
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Nao foi possivel salvar dba.yml: " + ex.getMessage());
        }
    }

    public void alternar(Player p) {
        if (ativos.remove(p.getUniqueId())) {
            p.sendMessage(Component.text("Durabilidade desativada.", NamedTextColor.RED));
        } else {
            ativos.add(p.getUniqueId());
            p.sendMessage(Component.text("Durabilidade ativada.", NamedTextColor.GREEN));
            mostrarFerramenta(p);
        }
        save();
    }

    private boolean ativo(Player p) {
        return ativos.contains(p.getUniqueId());
    }

    @EventHandler
    public void aoTrocarItem(PlayerItemHeldEvent e) {
        Player p = e.getPlayer();
        if (!ativo(p)) return;
        Bukkit.getScheduler().runTask(plugin, () -> mostrarFerramenta(p));
    }

    @EventHandler(ignoreCancelled = true)
    public void aoDanificar(PlayerItemDamageEvent e) {
        Player p = e.getPlayer();
        if (!ativo(p)) return;
        boolean armadura = ehArmadura(e.getItem().getType());
        // o dano é aplicado depois do evento, então esperamos 1 tick
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (armadura) mostrarArmadura(p);
            else mostrarFerramenta(p);
        });
    }

    private boolean ehArmadura(Material m) {
        String n = m.name();
        return n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE")
                || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS");
    }

    /** Retorna {max, restante} ou null se o item não tem durabilidade. */
    private int[] durab(ItemStack it) {
        if (it == null || it.getType().isAir()) return null;
        if (!(it.getItemMeta() instanceof Damageable d)) return null;
        int max = d.hasMaxDamage() ? d.getMaxDamage() : it.getType().getMaxDurability();
        if (max <= 0) return null;
        return new int[]{max, Math.max(0, max - d.getDamage())};
    }

    private void mostrarFerramenta(Player p) {
        if (!p.isOnline()) return;
        ItemStack it = p.getInventory().getItemInMainHand();
        int[] d = durab(it);
        if (d == null) return;
        int pct = (int) Math.round(100.0 * d[1] / d[0]);
        Component nome = Component.translatable(it.getType().translationKey());
        Component msg = Component.empty()
                .append(nome)
                .append(Component.text(": " + d[1] + "/" + d[0] + " (" + pct + "%)"))
                .color(Util.corPorcentagem(pct));
        p.sendActionBar(msg);
        verificarAviso(p, EquipmentSlot.HAND, it, nome, pct);
    }

    private void mostrarArmadura(Player p) {
        if (!p.isOnline()) return;
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        String[] nomes = {"Capacete", "Peitoral", "Calça", "Botas"};
        Component linha = Component.empty();
        boolean primeiro = true;
        List<Runnable> avisos = new ArrayList<>();

        for (int i = 0; i < slots.length; i++) {
            EquipmentSlot slot = slots[i];
            ItemStack it = p.getEquipment().getItem(slot);
            int[] d = durab(it);
            if (d == null) continue;
            int pct = (int) Math.round(100.0 * d[1] / d[0]);
            if (!primeiro) linha = linha.append(Component.text(" | ", NamedTextColor.GRAY));
            linha = linha.append(Component.text(nomes[i] + " " + pct + "%", Util.corPorcentagem(pct)));
            primeiro = false;
            Component nome = Component.translatable(it.getType().translationKey());
            avisos.add(() -> verificarAviso(p, slot, it, nome, pct));
        }
        if (primeiro) return;
        p.sendActionBar(linha);
        avisos.forEach(Runnable::run);
    }

    /** Avisa uma única vez quando o item chega a 10% ou menos. */
    private void verificarAviso(Player p, EquipmentSlot slot, ItemStack it, Component nome, int pct) {
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return;
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        boolean marcado = pdc.has(avisado, PersistentDataType.BYTE);

        if (pct <= 10 && !marcado) {
            pdc.set(avisado, PersistentDataType.BYTE, (byte) 1);
            it.setItemMeta(meta);
            p.getEquipment().setItem(slot, it);
            p.sendActionBar(Component.text("⚠ ").append(nome)
                    .append(Component.text(" quase quebrando!")).color(NamedTextColor.RED));
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 0.5f);
        } else if (pct > 10 && marcado) {
            pdc.remove(avisado); // foi consertado
            it.setItemMeta(meta);
            p.getEquipment().setItem(slot, it);
        }
    }
}
