package com.exemplo.survivalplus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * HUD fixo de durabilidade na barra de ação (acima da barra de XP).
 * Fica sempre visível: armadura à esquerda, ferramenta da mão à direita.
 * Por padrão está LIGADO para todos; /dba desliga e liga de novo.
 */
public class Dba implements Listener {

    private final SurvivalPlus plugin;
    private final File file;
    private final Set<UUID> desativados = new HashSet<>();
    private final NamespacedKey avisado;

    public Dba(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "dba.yml");
        this.avisado = new NamespacedKey(plugin, "dba_avisado");
        carregar();
        // atualiza o HUD 2x por segundo, assim ele fica sempre visível
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!desativados.contains(p.getUniqueId())) atualizar(p);
            }
        }, 10L, 10L);
    }

    private void carregar() {
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        for (String s : c.getStringList("desativados")) {
            try {
                desativados.add(UUID.fromString(s));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    public void save() {
        YamlConfiguration c = new YamlConfiguration();
        List<String> lista = new ArrayList<>();
        for (UUID u : desativados) lista.add(u.toString());
        c.set("desativados", lista);
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Nao foi possivel salvar dba.yml: " + ex.getMessage());
        }
    }

    public void alternar(Player p) {
        if (desativados.remove(p.getUniqueId())) {
            p.sendMessage(Component.text("Durabilidade ativada.", NamedTextColor.GREEN));
            atualizar(p);
        } else {
            desativados.add(p.getUniqueId());
            p.sendMessage(Component.text("Durabilidade desativada.", NamedTextColor.RED));
            p.sendActionBar(Component.empty());
        }
        save();
    }

    /** Retorna {max, restante} ou null se o item não tem durabilidade. */
    private int[] durab(ItemStack it) {
        if (it == null || it.getType().isAir()) return null;
        if (!(it.getItemMeta() instanceof Damageable d)) return null;
        int max = d.hasMaxDamage() ? d.getMaxDamage() : it.getType().getMaxDurability();
        if (max <= 0) return null;
        return new int[]{max, Math.max(0, max - d.getDamage())};
    }

    private void atualizar(Player p) {
        List<Runnable> avisos = new ArrayList<>();

        // ---- armadura ----
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        String[] nomes = {"Cap", "Pei", "Cal", "Bot"};
        Component armadura = null;
        for (int i = 0; i < slots.length; i++) {
            EquipmentSlot slot = slots[i];
            ItemStack it = p.getEquipment().getItem(slot);
            int[] d = durab(it);
            if (d == null) continue;
            int pct = (int) Math.round(100.0 * d[1] / d[0]);
            Component peca = Component.text(nomes[i] + " " + pct + "%", Util.corPorcentagem(pct));
            armadura = armadura == null ? peca : armadura.append(Component.text(" ")).append(peca);
            Component nome = Component.translatable(it.getType().translationKey());
            avisos.add(() -> verificarAviso(p, slot, it, nome, pct));
        }

        // ---- ferramenta na mão ----
        Component ferramenta = null;
        ItemStack mao = p.getInventory().getItemInMainHand();
        int[] dm = durab(mao);
        if (dm != null) {
            int pct = (int) Math.round(100.0 * dm[1] / dm[0]);
            Component nome = Component.translatable(mao.getType().translationKey());
            ferramenta = Component.empty()
                    .append(nome)
                    .append(Component.text(" " + dm[1] + "/" + dm[0]))
                    .color(Util.corPorcentagem(pct));
            avisos.add(() -> verificarAviso(p, EquipmentSlot.HAND, mao, nome, pct));
        }

        if (armadura == null && ferramenta == null) return;

        Component linha;
        if (armadura == null) linha = ferramenta;
        else if (ferramenta == null) linha = armadura;
        else linha = armadura.append(Component.text("  •  ", NamedTextColor.DARK_GRAY)).append(ferramenta);

        p.sendActionBar(linha);
        avisos.forEach(Runnable::run);
    }

    /** Avisa uma única vez (chat + som) quando o item chega a 10% ou menos. */
    private void verificarAviso(Player p, EquipmentSlot slot, ItemStack it, Component nome, int pct) {
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return;
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        boolean marcado = pdc.has(avisado, PersistentDataType.BYTE);

        if (pct <= 10 && !marcado) {
            pdc.set(avisado, PersistentDataType.BYTE, (byte) 1);
            it.setItemMeta(meta);
            p.getEquipment().setItem(slot, it);
            p.sendMessage(Component.text("⚠ ").append(nome)
                    .append(Component.text(" quase quebrando!")).color(NamedTextColor.RED));
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 0.5f);
        } else if (pct > 10 && marcado) {
            pdc.remove(avisado); // foi consertado
            it.setItemMeta(meta);
            p.getEquipment().setItem(slot, it);
        }
    }
}
