package com.exemplo.survivalplus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.Chest;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CompassMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Lápide: UM baú simples no chão que guarda os itens de 2 baús (54 slots).
 * Não pode ser quebrado, não explode, não queima. Só some quando o último item é retirado.
 * O XP nunca é perdido ao morrer.
 */
public class Tombs implements Listener {

    private static final int SLOTS = 54;
    private static final String TAG = "sp_lapide";

    static class Tomb {
        final UUID owner;
        final String world;
        final int x, y, z;
        ItemStack[] itens;
        Inventory inv;

        Tomb(UUID owner, String world, int x, int y, int z, ItemStack[] itens) {
            this.owner = owner;
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.itens = itens;
        }
    }

    static class TombHolder implements InventoryHolder {
        final Tomb tomb;
        Inventory inv;

        TombHolder(Tomb tomb) {
            this.tomb = tomb;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    record Aviso(Location local, boolean temBau) {}

    private final SurvivalPlus plugin;
    private final File file;
    private final Map<String, Tomb> blocos = new HashMap<>();
    private final Map<UUID, Aviso> pendentes = new HashMap<>();
    private final Map<UUID, Location> ultimoSeguro = new HashMap<>();

    public Tombs(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "tombs.yml");
        carregar();
    }

    // ---------------- persistência ----------------

    private static String key(String world, int x, int y, int z) {
        return world + ";" + x + ";" + y + ";" + z;
    }

    private void carregar() {
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection s = c.getConfigurationSection("tombs");
        if (s == null) return;
        for (String k : s.getKeys(false)) {
            ConfigurationSection t = s.getConfigurationSection(k);
            if (t == null) continue;
            String dados = t.getString("itens");
            if (dados == null) continue; // formato antigo (baú duplo): ignora
            try {
                ItemStack[] lidos = ItemStack.deserializeItemsFromBytes(Base64.getDecoder().decode(dados));
                ItemStack[] itens = new ItemStack[SLOTS];
                System.arraycopy(lidos, 0, itens, 0, Math.min(lidos.length, SLOTS));
                Tomb tomb = new Tomb(UUID.fromString(t.getString("owner", "")),
                        t.getString("world", ""), t.getInt("x"), t.getInt("y"), t.getInt("z"), itens);
                blocos.put(key(tomb.world, tomb.x, tomb.y, tomb.z), tomb);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Lapide invalida ignorada: " + k);
            }
        }
    }

    public void save() {
        YamlConfiguration c = new YamlConfiguration();
        int i = 0;
        for (Tomb t : blocos.values()) {
            if (t.inv != null) t.itens = t.inv.getContents();
            String base = "tombs." + i++;
            c.set(base + ".owner", t.owner.toString());
            c.set(base + ".world", t.world);
            c.set(base + ".x", t.x);
            c.set(base + ".y", t.y);
            c.set(base + ".z", t.z);
            c.set(base + ".itens", Base64.getEncoder().encodeToString(ItemStack.serializeItemsAsBytes(t.itens)));
        }
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Nao foi possivel salvar tombs.yml: " + ex.getMessage());
        }
    }

    // ---------------- utilidades ----------------

    private Tomb tombDe(Block b) {
        return blocos.get(key(b.getWorld().getName(), b.getX(), b.getY(), b.getZ()));
    }

    private boolean ehLapide(Block b) {
        return tombDe(b) != null;
    }

    private Tomb tombDe(Inventory inv) {
        InventoryHolder h = inv.getHolder();
        if (h instanceof TombHolder th) return th.tomb;
        if (h instanceof org.bukkit.block.Chest ch) return tombDe(ch.getBlock());
        return null;
    }

    private Inventory inventarioDe(Tomb t) {
        if (t.inv == null) {
            TombHolder h = new TombHolder(t);
            String dono = Bukkit.getOfflinePlayer(t.owner).getName();
            t.inv = Bukkit.createInventory(h, SLOTS,
                    Component.text("Lápide de " + (dono != null ? dono : "?"), NamedTextColor.DARK_GRAY));
            h.inv = t.inv;
            t.inv.setContents(t.itens);
        }
        return t.inv;
    }

    private boolean vazio(Inventory inv) {
        for (ItemStack i : inv.getContents()) {
            if (i != null && !i.getType().isAir()) return false;
        }
        return true;
    }

    private void fecharVisualizadores(Tomb t) {
        if (t.inv == null) return;
        for (HumanEntity v : new ArrayList<>(t.inv.getViewers())) v.closeInventory();
    }

    private void removerLapide(Tomb t) {
        fecharVisualizadores(t);
        removerHolograma(t.world, t.x, t.y, t.z);
        World w = Bukkit.getWorld(t.world);
        if (w != null) {
            Block b = w.getBlockAt(t.x, t.y, t.z);
            if (b.getType() == Material.CHEST) b.setType(Material.AIR, false);
        }
        blocos.remove(key(t.world, t.x, t.y, t.z));
        save();
    }

    // ---------------- morte ----------------

    @EventHandler(priority = EventPriority.HIGH)
    public void aoMorrer(PlayerDeathEvent e) {
        Player p = e.getEntity();
        UUID uuid = p.getUniqueId();

        // XP nunca é perdido
        e.setKeepLevel(true);
        e.setDroppedExp(0);

        Location morte = p.getLocation();
        List<ItemStack> itens = new ArrayList<>();
        for (ItemStack i : e.getDrops()) {
            if (i != null && !i.getType().isAir()) itens.add(i.clone());
        }
        if (e.getKeepInventory() || itens.isEmpty()) {
            pendentes.put(uuid, new Aviso(morte, false));
            return;
        }
        e.getDrops().clear();

        Block bloco = acharBloco(morte);
        if (bloco == null) {
            Location seguro = ultimoSeguro.get(uuid);
            if (seguro != null) bloco = acharBloco(seguro);
        }
        if (bloco == null) {
            // última opção: solta os itens no chão
            Location onde = ultimoSeguro.getOrDefault(uuid, morte);
            for (ItemStack i : itens) onde.getWorld().dropItemNaturally(onde, i);
            pendentes.put(uuid, new Aviso(onde, false));
            return;
        }

        bloco.setType(Material.CHEST, false);
        Chest dados = (Chest) bloco.getBlockData();
        dados.setFacing(BlockFace.NORTH);
        dados.setType(Chest.Type.SINGLE);
        bloco.setBlockData(dados, false);

        ItemStack[] conteudo = new ItemStack[SLOTS];
        for (int i = 0; i < itens.size(); i++) {
            if (i < SLOTS) conteudo[i] = itens.get(i);
            else bloco.getWorld().dropItemNaturally(bloco.getLocation(), itens.get(i));
        }

        Tomb tomb = new Tomb(uuid, bloco.getWorld().getName(), bloco.getX(), bloco.getY(), bloco.getZ(), conteudo);
        blocos.put(key(tomb.world, tomb.x, tomb.y, tomb.z), tomb);
        save();
        pendentes.put(uuid, new Aviso(bloco.getLocation(), true));
        criarHolograma(bloco, p.getName(), causaDaMorte(p));
    }

    /** Procura um bloco livre, com chão embaixo, perto da localização. */
    private Block acharBloco(Location loc) {
        World w = loc.getWorld();
        if (w == null || loc.getY() < w.getMinHeight()) return null; // morreu no void
        int cx = loc.getBlockX(), cy = loc.getBlockY(), cz = loc.getBlockZ();
        int minY = w.getMinHeight() + 1, maxY = w.getMaxHeight() - 2;

        for (int d = 0; d <= 6; d++) {
            for (int dx = -d; dx <= d; dx++) {
                for (int dy = -d; dy <= d; dy++) {
                    for (int dz = -d; dz <= d; dz++) {
                        if (Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz))) != d) continue;
                        int y = cy + dy;
                        if (y < minY || y > maxY) continue;
                        Block b = w.getBlockAt(cx + dx, y, cz + dz);
                        if (livre(b) && apoio(b) && !ehLapide(b)) return b;
                    }
                }
            }
        }
        return null;
    }

    private boolean livre(Block b) {
        Material m = b.getType();
        if (m == Material.LAVA) return false;
        return m.isAir() || b.isReplaceable();
    }

    private boolean apoio(Block b) {
        return b.getRelative(BlockFace.DOWN).getType().isSolid();
    }

    // ---------------- holograma: nome e causa da morte ----------------

    private Component causaDaMorte(Player p) {
        EntityDamageEvent ev = p.getLastDamageCause();
        if (ev == null) return Component.text("Desconhecida");

        if (ev instanceof EntityDamageByEntityEvent ee) {
            Entity autor = ee.getDamager();
            if (autor instanceof Projectile proj && proj.getShooter() instanceof Entity atirador) {
                autor = atirador;
            }
            Component quem = autor instanceof Player jogador
                    ? Component.text(jogador.getName())
                    : Component.translatable(autor.getType().translationKey());
            return Component.text("Morto por ").append(quem);
        }

        String causa = switch (ev.getCause().name()) {
            case "FALL" -> "Queda";
            case "LAVA" -> "Lava";
            case "FIRE", "FIRE_TICK" -> "Fogo";
            case "HOT_FLOOR" -> "Bloco de magma";
            case "CAMPFIRE" -> "Fogueira";
            case "DROWNING" -> "Afogamento";
            case "VOID" -> "Void";
            case "SUFFOCATION" -> "Sufocamento";
            case "STARVATION" -> "Fome";
            case "POISON" -> "Veneno";
            case "WITHER" -> "Efeito Wither";
            case "MAGIC" -> "Magia";
            case "LIGHTNING" -> "Raio";
            case "CONTACT" -> "Cacto ou espinhos";
            case "BLOCK_EXPLOSION", "ENTITY_EXPLOSION" -> "Explosão";
            case "FALLING_BLOCK" -> "Bloco caindo";
            case "FREEZE" -> "Congelamento";
            case "FLY_INTO_WALL" -> "Colisão ao voar";
            case "CRAMMING" -> "Esmagamento";
            case "DRAGON_BREATH" -> "Sopro do dragão";
            case "SONIC_BOOM" -> "Grito do Warden";
            case "SUICIDE", "KILL" -> "Comando";
            case "THORNS" -> "Espinhos";
            default -> "Desconhecida";
        };
        return Component.text(causa);
    }

    private void criarHolograma(Block bloco, String nome, Component causa) {
        Location l = bloco.getLocation().add(0.5, 1.4, 0.5);
        Component texto = Component.text("☠ " + nome, NamedTextColor.RED)
                .append(Component.newline())
                .append(Component.text("Causa: ", NamedTextColor.GRAY))
                .append(causa.color(NamedTextColor.WHITE));
        bloco.getWorld().spawn(l, TextDisplay.class, d -> {
            d.text(texto);
            d.setBillboard(Display.Billboard.CENTER);
            d.setAlignment(TextDisplay.TextAlignment.CENTER);
            d.addScoreboardTag(TAG);
        });
    }

    private void removerHolograma(String mundo, int x, int y, int z) {
        World w = Bukkit.getWorld(mundo);
        if (w == null) return;
        Location centro = new Location(w, x + 0.5, y + 1.4, z + 0.5);
        for (Entity en : w.getNearbyEntities(centro, 1, 1, 1)) {
            if (en instanceof TextDisplay && en.getScoreboardTags().contains(TAG)) en.remove();
        }
    }

    // ---------------- renascer: bússola + coordenadas ----------------

    @EventHandler
    public void aoRenascer(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Aviso av = pendentes.remove(p.getUniqueId());
        if (av == null) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> entregar(p, av), 5L);
    }

    private void entregar(Player p, Aviso av) {
        if (!p.isOnline()) return;
        Location l = av.local();
        String dim = switch (l.getWorld().getEnvironment()) {
            case NETHER -> "Nether";
            case THE_END -> "The End";
            default -> "Overworld";
        };
        String coords = "X: " + l.getBlockX() + "  Y: " + l.getBlockY() + "  Z: " + l.getBlockZ() + "  (" + dim + ")";

        p.sendMessage(Component.text("☠ Local da morte: ", NamedTextColor.RED)
                .append(Component.text(coords, NamedTextColor.YELLOW)));
        if (av.temBau()) {
            p.sendMessage(Component.text("Seus itens estão num baú lá. Ele some quando você pegar tudo. Seu XP foi mantido.",
                    NamedTextColor.GREEN));
        } else {
            p.sendMessage(Component.text("Seu XP foi mantido.", NamedTextColor.GREEN));
        }

        ItemStack bussola = new ItemStack(Material.COMPASS);
        CompassMeta meta = (CompassMeta) bussola.getItemMeta();
        meta.setLodestone(l);
        meta.setLodestoneTracked(false); // aponta mesmo sem pedra-ímã
        meta.displayName(Util.txt("Bússola da Morte", NamedTextColor.RED));
        meta.lore(List.of(Util.txt(coords, NamedTextColor.GRAY)));
        bussola.setItemMeta(meta);
        for (ItemStack sobra : p.getInventory().addItem(bussola).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), sobra);
        }
    }

    // ---------------- abrir (baú de 54 slots) ----------------

    @EventHandler(priority = EventPriority.HIGH)
    public void aoClicarBau(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block b = e.getClickedBlock();
        if (b == null) return;
        Tomb t = tombDe(b);
        if (t == null) return;

        e.setCancelled(true); // nunca abre o baú de verdade
        if (e.getHand() != EquipmentSlot.HAND) return;

        Player p = e.getPlayer();
        if (!p.getUniqueId().equals(t.owner) && !p.hasPermission("lapide.admin")) {
            p.sendMessage(Component.text("Essa lápide não é sua.", NamedTextColor.RED));
            return;
        }
        p.openInventory(inventarioDe(t));
    }

    @EventHandler(ignoreCancelled = true)
    public void aoAbrirBauReal(InventoryOpenEvent e) {
        if (e.getInventory().getHolder() instanceof org.bukkit.block.Chest ch && ehLapide(ch.getBlock())) {
            e.setCancelled(true);
        }
    }

    /** Só dá para retirar itens: não deixa colocar itens na lápide. */
    @EventHandler
    public void aoClicarInventario(InventoryClickEvent e) {
        Inventory topo = e.getView().getTopInventory();
        if (!(topo.getHolder() instanceof TombHolder)) return;
        Inventory clicado = e.getClickedInventory();
        if (clicado == null) return;

        if (clicado == topo) {
            ItemStack cursor = e.getCursor();
            if (cursor != null && !cursor.getType().isAir()) {
                e.setCancelled(true);
                return;
            }
            ClickType ck = e.getClick();
            if (e.getWhoClicked() instanceof Player p) {
                ItemStack alvo = null;
                if (ck == ClickType.NUMBER_KEY) alvo = p.getInventory().getItem(e.getHotbarButton());
                else if (ck == ClickType.SWAP_OFFHAND) alvo = p.getInventory().getItemInOffHand();
                if (alvo != null && !alvo.getType().isAir()) e.setCancelled(true);
            }
        } else if (e.isShiftClick()) {
            e.setCancelled(true); // shift-click do seu inventário para a lápide
        }
    }

    @EventHandler
    public void aoArrastar(InventoryDragEvent e) {
        Inventory topo = e.getView().getTopInventory();
        if (!(topo.getHolder() instanceof TombHolder)) return;
        for (int slot : e.getRawSlots()) {
            if (slot < topo.getSize()) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void aoFechar(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof TombHolder th)) return;
        Tomb t = th.tomb;
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!blocos.containsKey(key(t.world, t.x, t.y, t.z))) return;
            if (t.inv != null && vazio(t.inv)) {
                removerLapide(t); // pegou tudo: o baú some
            } else {
                save();
            }
        });
    }

    // ---------------- indestrutível ----------------

    @EventHandler(ignoreCancelled = true)
    public void aoQuebrar(BlockBreakEvent e) {
        Tomb t = tombDe(e.getBlock());
        if (t == null) return;
        if (e.getPlayer().hasPermission("lapide.admin")) {
            // admin quebrou: solta os itens e remove o registro
            fecharVisualizadores(t);
            removerHolograma(t.world, t.x, t.y, t.z);
            ItemStack[] cont = t.inv != null ? t.inv.getContents() : t.itens;
            Location l = e.getBlock().getLocation();
            for (ItemStack i : cont) {
                if (i != null && !i.getType().isAir()) l.getWorld().dropItemNaturally(l, i);
            }
            blocos.remove(key(t.world, t.x, t.y, t.z));
            save();
            return;
        }
        e.setCancelled(true);
        e.getPlayer().sendMessage(Component.text("Essa lápide não pode ser quebrada.", NamedTextColor.RED));
    }

    @EventHandler(ignoreCancelled = true)
    public void aoExplodir(EntityExplodeEvent e) {
        e.blockList().removeIf(this::ehLapide);
    }

    @EventHandler(ignoreCancelled = true)
    public void aoExplodirBloco(BlockExplodeEvent e) {
        e.blockList().removeIf(this::ehLapide);
    }

    @EventHandler(ignoreCancelled = true)
    public void aoQueimar(BlockBurnEvent e) {
        if (ehLapide(e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void aoMudarBloco(EntityChangeBlockEvent e) {
        if (ehLapide(e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void aoEmpurrar(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (ehLapide(b)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void aoPuxar(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) {
            if (ehLapide(b)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void aoMoverItem(InventoryMoveItemEvent e) {
        if (tombDe(e.getSource()) != null || tombDe(e.getDestination()) != null) {
            e.setCancelled(true); // funis não mexem na lápide
        }
    }

    // ---------------- último lugar seguro (para morte no void) ----------------

    @EventHandler(ignoreCancelled = true)
    public void aoMover(PlayerMoveEvent e) {
        Location de = e.getFrom();
        Location para = e.getTo();
        if (para == null) return;
        if (de.getBlockX() == para.getBlockX() && de.getBlockY() == para.getBlockY()
                && de.getBlockZ() == para.getBlockZ()) return;
        Player p = e.getPlayer();
        if (p.isOnGround()) ultimoSeguro.put(p.getUniqueId(), para.clone());
    }
}
