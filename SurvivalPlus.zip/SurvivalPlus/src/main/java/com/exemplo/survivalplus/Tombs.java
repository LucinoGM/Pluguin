package com.exemplo.survivalplus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.DoubleChest;
import org.bukkit.block.data.type.Chest;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.DoubleChestInventory;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CompassMeta;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class Tombs implements Listener {

    /** A lápide ocupa dois blocos: (x,y,z) e (x+1,y,z). */
    record Tomb(UUID owner, String world, int x, int y, int z) {}

    record Aviso(Location local, boolean temBau) {}

    private final SurvivalPlus plugin;
    private final File file;
    private final Map<String, Tomb> blocos = new HashMap<>();
    private final Map<UUID, Aviso> pendentes = new HashMap<>();
    private final Map<UUID, Location> ultimoSeguro = new HashMap<>();

    public Tombs(SurvivalPlus plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "tombs.yml");
        carregar();
    }

    // ---------------- persistência ----------------

    private static String key(String world, int x, int y, int z) {
        return world + ";" + x + ";" + y + ";" + z;
    }

    private void registrar(Tomb t) {
        blocos.put(key(t.world(), t.x(), t.y(), t.z()), t);
        blocos.put(key(t.world(), t.x() + 1, t.y(), t.z()), t);
    }

    private void carregar() {
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection s = c.getConfigurationSection("tombs");
        if (s == null) return;
        for (String k : s.getKeys(false)) {
            ConfigurationSection t = s.getConfigurationSection(k);
            if (t == null) continue;
            try {
                registrar(new Tomb(UUID.fromString(t.getString("owner", "")),
                        t.getString("world", ""), t.getInt("x"), t.getInt("y"), t.getInt("z")));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    public void save() {
        YamlConfiguration c = new YamlConfiguration();
        int i = 0;
        for (Tomb t : new LinkedHashSet<>(blocos.values())) {
            String base = "tombs." + i++;
            c.set(base + ".owner", t.owner().toString());
            c.set(base + ".world", t.world());
            c.set(base + ".x", t.x());
            c.set(base + ".y", t.y());
            c.set(base + ".z", t.z());
        }
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Nao foi possivel salvar tombs.yml: " + ex.getMessage());
        }
    }

    // ---------------- utilidades ----------------

    private Tomb tombDe(Block b) {
        return blocos.get(key(b.getWorld().getName(), b.getX(), b.getY(), b.getZ()));
    }

    private boolean ehLapide(Block b) {
        return tombDe(b) != null;
    }

    private Tomb tombDe(Inventory inv) {
        InventoryHolder h = inv.getHolder();
        if (h instanceof DoubleChest dc) h = dc.getLeftSide();
        if (h instanceof org.bukkit.block.Chest ch) return tombDe(ch.getBlock());
        return null;
    }

    private boolean vazio(Inventory inv) {
        for (ItemStack i : inv.getContents()) {
            if (i != null && !i.getType().isAir()) return false;
        }
        return true;
    }

    private void removerLapide(Tomb t) {
        World w = Bukkit.getWorld(t.world());
        if (w != null) {
            for (int dx = 0; dx <= 1; dx++) {
                Block b = w.getBlockAt(t.x() + dx, t.y(), t.z());
                if (b.getType() == Material.CHEST) b.setType(Material.AIR, false);
            }
        }
        blocos.remove(key(t.world(), t.x(), t.y(), t.z()));
        blocos.remove(key(t.world(), t.x() + 1, t.y(), t.z()));
        save();
    }

    private void unregister(Tomb t) {
        blocos.remove(key(t.world(), t.x(), t.y(), t.z()));
        blocos.remove(key(t.world(), t.x() + 1, t.y(), t.z()));
        save();
    }

    // ---------------- morte ----------------

    @EventHandler(priority = EventPriority.HIGH)
    public void aoMorrer(PlayerDeathEvent e) {
        Player p = e.getEntity();
        UUID uuid = p.getUniqueId();

        // XP nunca é perdido
        e.setKeepLevel(true);
        e.setDroppedExp(0);

        Location morte = p.getLocation();
        List<ItemStack> itens = new ArrayList<>();
        for (ItemStack i : e.getDrops()) {
            if (i != null && !i.getType().isAir()) itens.add(i.clone());
        }
        if (e.getKeepInventory() || itens.isEmpty()) {
            pendentes.put(uuid, new Aviso(morte, false));
            return;
        }
        e.getDrops().clear();

        Block[] par = acharPar(morte);
        if (par == null) {
            Location seguro = ultimoSeguro.get(uuid);
            if (seguro != null) par = acharPar(seguro);
        }
        if (par == null) {
            // última opção: solta os itens no chão
            Location onde = ultimoSeguro.getOrDefault(uuid, morte);
            for (ItemStack i : itens) onde.getWorld().dropItemNaturally(onde, i);
            pendentes.put(uuid, new Aviso(onde, false));
            return;
        }

        Block a = par[0];
        Block b = par[1];
        if (!criarBau(a, b)) {
            a.setType(Material.AIR, false);
            b.setType(Material.AIR, false);
            for (ItemStack i : itens) morte.getWorld().dropItemNaturally(morte, i);
            pendentes.put(uuid, new Aviso(morte, false));
            return;
        }

        Inventory inv = ((org.bukkit.block.Chest) a.getState()).getInventory();
        for (ItemStack sobra : inv.addItem(itens.toArray(new ItemStack[0])).values()) {
            a.getWorld().dropItemNaturally(a.getLocation(), sobra);
        }

        registrar(new Tomb(uuid, a.getWorld().getName(), a.getX(), a.getY(), a.getZ()));
        save();
        pendentes.put(uuid, new Aviso(a.getLocation(), true));
    }

    /** Procura dois blocos lado a lado (x e x+1) livres, com chão embaixo, perto da localização. */
    private Block[] acharPar(Location loc) {
        World w = loc.getWorld();
        if (w == null || loc.getY() < w.getMinHeight()) return null; // morreu no void
        int cx = loc.getBlockX(), cy = loc.getBlockY(), cz = loc.getBlockZ();
        int minY = w.getMinHeight() + 1, maxY = w.getMaxHeight() - 2;

        for (int d = 0; d <= 6; d++) {
            for (int dx = -d; dx <= d; dx++) {
                for (int dy = -d; dy <= d; dy++) {
                    for (int dz = -d; dz <= d; dz++) {
                        if (Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz))) != d) continue;
                        int y = cy + dy;
                        if (y < minY || y > maxY) continue;
                        Block a = w.getBlockAt(cx + dx, y, cz + dz);
                        Block b = w.getBlockAt(cx + dx + 1, y, cz + dz);
                        if (livre(a) && livre(b) && apoio(a) && apoio(b)) return new Block[]{a, b};
                    }
                }
            }
        }
        return null;
    }

    private boolean livre(Block b) {
        Material m = b.getType();
        if (m == Material.LAVA) return false;
        return m.isAir() || b.isReplaceable();
    }

    private boolean apoio(Block b) {
        return b.getRelative(BlockFace.DOWN).getType().isSolid();
    }

    private boolean criarBau(Block a, Block b) {
        colocar(a, Chest.Type.LEFT);
        colocar(b, Chest.Type.RIGHT);
        if (!ehDuplo(a)) {
            colocar(a, Chest.Type.RIGHT);
            colocar(b, Chest.Type.LEFT);
        }
        return ehDuplo(a);
    }

    private void colocar(Block bloco, Chest.Type tipo) {
        bloco.setType(Material.CHEST, false);
        Chest dados = (Chest) bloco.getBlockData();
        dados.setFacing(BlockFace.NORTH);
        dados.setType(tipo);
        bloco.setBlockData(dados, false);
    }

    private boolean ehDuplo(Block a) {
        return a.getState() instanceof org.bukkit.block.Chest ch
                && ch.getInventory() instanceof DoubleChestInventory;
    }

    // ---------------- renascer: bússola + coordenadas ----------------

    @EventHandler
    public void aoRenascer(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Aviso av = pendentes.remove(p.getUniqueId());
        if (av == null) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> entregar(p, av), 5L);
    }

    private void entregar(Player p, Aviso av) {
        if (!p.isOnline()) return;
        Location l = av.local();
        String dim = switch (l.getWorld().getEnvironment()) {
            case NETHER -> "Nether";
            case THE_END -> "The End";
            default -> "Overworld";
        };
        String coords = "X: " + l.getBlockX() + "  Y: " + l.getBlockY() + "  Z: " + l.getBlockZ() + "  (" + dim + ")";

        p.sendMessage(Component.text("☠ Local da morte: ", NamedTextColor.RED)
                .append(Component.text(coords, NamedTextColor.YELLOW)));
        if (av.temBau()) {
            p.sendMessage(Component.text("Seus itens estão num baú lá. Ele some quando você pegar tudo. Seu XP foi mantido.",
                    NamedTextColor.GREEN));
        } else {
            p.sendMessage(Component.text("Seu XP foi mantido.", NamedTextColor.GREEN));
        }

        ItemStack bussola = new ItemStack(Material.COMPASS);
        CompassMeta meta = (CompassMeta) bussola.getItemMeta();
        meta.setLodestone(l);
        meta.setLodestoneTracked(false); // aponta mesmo sem pedra-ímã
        meta.displayName(Util.txt("Bússola da Morte", NamedTextColor.RED));
        meta.lore(List.of(Util.txt(coords, NamedTextColor.GRAY)));
        bussola.setItemMeta(meta);
        for (ItemStack sobra : p.getInventory().addItem(bussola).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), sobra);
        }
    }

    // ---------------- abrir / esvaziar ----------------

    @EventHandler(ignoreCancelled = true)
    public void aoAbrir(InventoryOpenEvent e) {
        Tomb t = tombDe(e.getInventory());
        if (t == null) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        if (p.getUniqueId().equals(t.owner()) || p.hasPermission("lapide.admin")) return;
        e.setCancelled(true);
        p.sendMessage(Component.text("Essa lápide não é sua.", NamedTextColor.RED));
    }

    @EventHandler
    public void aoFechar(InventoryCloseEvent e) {
        Tomb t = tombDe(e.getInventory());
        if (t == null) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            World w = Bukkit.getWorld(t.world());
            if (w == null) return;
            Block a = w.getBlockAt(t.x(), t.y(), t.z());
            if (a.getState() instanceof org.bukkit.block.Chest ch && vazio(ch.getInventory())) {
                removerLapide(t);
            }
        });
    }

    // ---------------- indestrutível ----------------

    @EventHandler(ignoreCancelled = true)
    public void aoQuebrar(BlockBreakEvent e) {
        Tomb t = tombDe(e.getBlock());
        if (t == null) return;
        if (e.getPlayer().hasPermission("lapide.admin")) {
            unregister(t);
            return;
        }
        e.setCancelled(true);
        e.getPlayer().sendMessage(Component.text("Essa lápide não pode ser quebrada.", NamedTextColor.RED));
    }

    @EventHandler(ignoreCancelled = true)
    public void aoExplodir(EntityExplodeEvent e) {
        e.blockList().removeIf(this::ehLapide);
    }

    @EventHandler(ignoreCancelled = true)
    public void aoExplodirBloco(BlockExplodeEvent e) {
        e.blockList().removeIf(this::ehLapide);
    }

    @EventHandler(ignoreCancelled = true)
    public void aoQueimar(BlockBurnEvent e) {
        if (ehLapide(e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void aoMudarBloco(EntityChangeBlockEvent e) {
        if (ehLapide(e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void aoEmpurrar(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (ehLapide(b)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void aoPuxar(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) {
            if (ehLapide(b)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void aoMoverItem(InventoryMoveItemEvent e) {
        if (tombDe(e.getSource()) != null || tombDe(e.getDestination()) != null) {
            e.setCancelled(true); // funis não mexem na lápide
        }
    }

    // ---------------- último lugar seguro (para morte no void) ----------------

    @EventHandler(ignoreCancelled = true)
    public void aoMover(PlayerMoveEvent e) {
        Location de = e.getFrom();
        Location para = e.getTo();
        if (para == null) return;
        if (de.getBlockX() == para.getBlockX() && de.getBlockY() == para.getBlockY()
                && de.getBlockZ() == para.getBlockZ()) return;
        Player p = e.getPlayer();
        if (p.isOnGround()) ultimoSeguro.put(p.getUniqueId(), para.clone());
    }
}
