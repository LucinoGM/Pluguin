package com.exemplo.survivalplus;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class NightLuz {

    private static final int SEGUNDOS_ACTIONBAR = 10;

    private final SurvivalPlus plugin;
    private final Dba dba;
    private final Map<UUID, BukkitTask> tarefas = new HashMap<>();

    public NightLuz(SurvivalPlus plugin, Dba dba) {
        this.plugin = plugin;
        this.dba = dba;
    }

    public void parar() {
        tarefas.values().forEach(BukkitTask::cancel);
        tarefas.clear();
    }

    public void alternar(Player player) {
        if (!player.hasPermission("nightluz.use")) {
            player.sendMessage(Component.text("Você não tem permissão.", NamedTextColor.RED));
            return;
        }

        boolean estavaAtivo = player.hasPotionEffect(PotionEffectType.NIGHT_VISION);
        if (estavaAtivo) {
            player.removePotionEffect(PotionEffectType.NIGHT_VISION);
        } else {
            player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,
                    PotionEffect.INFINITE_DURATION, 0, false, false, false));
        }

        Component msg = estavaAtivo
                ? Component.text("Night Vision desativada", NamedTextColor.RED)
                : Component.text("Night Vision ativada", NamedTextColor.GREEN);
        player.sendMessage(msg);
        mostrarActionBar(player, msg);
    }

    private void mostrarActionBar(Player player, Component msg) {
        BukkitTask antiga = tarefas.remove(player.getUniqueId());
        if (antiga != null) antiga.cancel();

        // enquanto a mensagem aparece (10s), o HUD de durabilidade fica pausado
        dba.pausar(player, SEGUNDOS_ACTIONBAR * 1000L);

        BukkitTask nova = new BukkitRunnable() {
            int segundos = 0;

            @Override
            public void run() {
                if (!player.isOnline() || segundos >= SEGUNDOS_ACTIONBAR) {
                    tarefas.remove(player.getUniqueId());
                    cancel();
                    return;
                }
                player.sendActionBar(msg);
                segundos++;
            }
        }.runTaskTimer(plugin, 0L, 20L);

        tarefas.put(player.getUniqueId(), nova);
    }
}
