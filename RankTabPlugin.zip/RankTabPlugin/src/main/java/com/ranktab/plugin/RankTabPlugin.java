package com.ranktab.plugin;

import org.bukkit.plugin.java.JavaPlugin;

public class RankTabPlugin extends JavaPlugin {

    private static RankTabPlugin instance;
    private CargoManager cargoManager;
    private InvCheckManager invCheckManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.cargoManager = new CargoManager(this);
        this.invCheckManager = new InvCheckManager(this);

        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new InvCheckListener(this), this);

        getCommand("setcargo").setExecutor(new SetCargoCommand(this));
        getCommand("inv").setExecutor(new InvCommand(this));
        getCommand("verinv").setExecutor(new VerInvCommand(this));

        cargoManager.updateAllPlayersTab();

        getLogger().info("RankTabPlugin ativado com sucesso!");
    }

    @Override
    public void onDisable() {
        cargoManager.cleanup();
        getLogger().info("RankTabPlugin desativado!");
    }

    public static RankTabPlugin getInstance() {
        return instance;
    }

    public CargoManager getCargoManager() {
        return cargoManager;
    }

    public InvCheckManager getInvCheckManager() {
        return invCheckManager;
    }
}
