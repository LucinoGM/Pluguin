package com.ranktab.plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetCargoCommand implements CommandExecutor {

    private final RankTabPlugin plugin;

    public SetCargoCommand(RankTabPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(Component.text("Uso: /setcargo <player> <1|2|3>").color(NamedTextColor.RED));
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            sender.sendMessage(Component.text("Jogador nao encontrado!").color(NamedTextColor.RED));
            return true;
        }

        int rank;
        try {
            rank = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            sender.sendMessage(Component.text("Cargo invalido! Use 1 (Dono), 2 (Vip) ou 3 (Membro)").color(NamedTextColor.RED));
            return true;
        }

        if (!plugin.getCargoManager().isValidRank(rank)) {
            sender.sendMessage(Component.text("Cargo invalido! Use 1 (Dono), 2 (Vip) ou 3 (Membro)").color(NamedTextColor.RED));
            return true;
        }

        plugin.getCargoManager().setPlayerRank(target.getUniqueId(), rank);

        String cargoNome = plugin.getCargoManager().getCargos().get(rank).getNome();
        sender.sendMessage(Component.text("Cargo de ").color(NamedTextColor.GREEN)
            .append(Component.text(target.getName()).color(NamedTextColor.YELLOW))
            .append(Component.text(" definido para ").color(NamedTextColor.GREEN))
            .append(Component.text(cargoNome).color(NamedTextColor.AQUA)));

        target.sendMessage(Component.text("Seu cargo foi atualizado para ").color(NamedTextColor.GREEN)
            .append(Component.text(cargoNome).color(NamedTextColor.AQUA)));

        return true;
    }
}
