package com.ranktab.plugin;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class PlayerListener implements Listener {

    private final RankTabPlugin plugin;

    public PlayerListener(RankTabPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Se for OP, automaticamente vira Dono (cargo 1)
        if (player.isOp()) {
            plugin.getCargoManager().setPlayerRank(player.getUniqueId(), 1);
        }

        // Atualiza TAB
        new BukkitRunnable() {
            @Override
            public void run() {
                plugin.getCargoManager().updatePlayerTab(player);
            }
        }.runTaskLater(plugin, 5L);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        plugin.getCargoManager().savePlayerData();
    }
}
