package com.ranktab.plugin;

import net.kyori.adventure.text.format.TextColor;

public class CargoInfo {
    private final String nome;
    private final String corHex;
    private final boolean negrito;

    public CargoInfo(String nome, String corHex, boolean negrito) {
        this.nome = nome;
        this.corHex = corHex;
        this.negrito = negrito;
    }

    public String getNome() {
        return nome;
    }

    public TextColor getColor() {
        return TextColor.fromHexString(corHex);
    }

    public boolean isNegrito() {
        return negrito;
    }
}
