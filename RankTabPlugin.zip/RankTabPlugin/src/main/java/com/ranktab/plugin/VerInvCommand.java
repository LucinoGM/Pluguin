package com.ranktab.plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class VerInvCommand implements CommandExecutor {

    private final RankTabPlugin plugin;

    public VerInvCommand(RankTabPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Apenas jogadores podem usar este comando!");
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(Component.text("Uso: /verinv <player>").color(NamedTextColor.RED));
            return true;
        }

        Player admin = (Player) sender;
        Player target = Bukkit.getPlayer(args[0]);

        if (target == null) {
            admin.sendMessage(Component.text("Jogador nao encontrado!").color(NamedTextColor.RED));
            return true;
        }

        plugin.getInvCheckManager().openPlayerInventoryRemote(admin, target);
        admin.sendMessage(Component.text("Abrindo inventario de ").color(NamedTextColor.GREEN)
            .append(Component.text(target.getName()).color(NamedTextColor.YELLOW)));

        return true;
    }
}
