package com.ranktab.plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.*;

public class CargoManager {

    private final RankTabPlugin plugin;
    private final Map<UUID, Integer> playerRanks = new HashMap<>();
    private final Map<Integer, CargoInfo> cargos = new LinkedHashMap<>();
    private final Scoreboard scoreboard;

    public CargoManager(RankTabPlugin plugin) {
        this.plugin = plugin;
        this.scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        loadCargos();
        loadPlayerData();
        setupTeams();
    }

    private void loadCargos() {
        FileConfiguration config = plugin.getConfig();

        cargos.put(1, new CargoInfo(
            config.getString("cargos.dono.nome", "Dono"),
            config.getString("cargos.dono.cor", "#00BFFF"),
            config.getBoolean("cargos.dono.negrito", true)
        ));

        cargos.put(2, new CargoInfo(
            config.getString("cargos.vip.nome", "Vip"),
            config.getString("cargos.vip.cor", "#FFFF00"),
            config.getBoolean("cargos.vip.negrito", false)
        ));

        cargos.put(3, new CargoInfo(
            config.getString("cargos.membro.nome", "Membro"),
            config.getString("cargos.membro.cor", "#808080"),
            config.getBoolean("cargos.membro.negrito", false)
        ));
    }

    private void setupTeams() {
        for (Map.Entry<Integer, CargoInfo> entry : cargos.entrySet()) {
            String teamName = "rank_" + entry.getKey();
            Team team = scoreboard.getTeam(teamName);
            if (team == null) {
                team = scoreboard.registerNewTeam(teamName);
            }

            CargoInfo cargo = entry.getValue();
            Component prefix = Component.text("[" + cargo.getNome() + "] ")
                .color(NamedTextColor.nearestTo(cargo.getColor()));

            if (cargo.isNegrito()) {
                prefix = prefix.decorate(TextDecoration.BOLD);
            }

            team.prefix(prefix);
            team.setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.ALWAYS);
            team.setOption(Team.Option.COLLISION_RULE, Team.OptionStatus.ALWAYS);
        }
    }

    public void loadPlayerData() {
        FileConfiguration config = plugin.getConfig();
        if (config.contains("players")) {
            for (String key : config.getConfigurationSection("players").getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(key);
                    int rank = config.getInt("players." + key + ".cargo", 3);
                    playerRanks.put(uuid, rank);
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("UUID invalido: " + key);
                }
            }
        }
    }

    public void savePlayerData() {
        FileConfiguration config = plugin.getConfig();
        for (Map.Entry<UUID, Integer> entry : playerRanks.entrySet()) {
            config.set("players." + entry.getKey().toString() + ".cargo", entry.getValue());
        }
        plugin.saveConfig();
    }

    public int getPlayerRank(UUID uuid) {
        return playerRanks.getOrDefault(uuid, 3);
    }

    public void setPlayerRank(UUID uuid, int rank) {
        playerRanks.put(uuid, rank);
        savePlayerData();

        Player player = Bukkit.getPlayer(uuid);
        if (player != null && player.isOnline()) {
            updatePlayerTab(player);
        }
    }

    public void updatePlayerTab(Player player) {
        int rank = getPlayerRank(player.getUniqueId());

        // Remove de todos os times
        for (Team team : scoreboard.getTeams()) {
            team.removeEntry(player.getName());
        }

        // Adiciona ao time correto
        String teamName = "rank_" + rank;
        Team team = scoreboard.getTeam(teamName);
        if (team != null) {
            team.addEntry(player.getName());
        }

        // Aplica scoreboard ao player
        player.setScoreboard(scoreboard);

        // Atualiza header/footer com ping
        updatePingDisplay(player);
    }

    public void updatePingDisplay(Player player) {
        int ping = player.getPing();
        Component header = Component.text("")
            .append(Component.text("=== Servidor ===").color(NamedTextColor.GREEN).decorate(TextDecoration.BOLD))
            .append(Component.newline())
            .append(Component.text("Bem-vindo!").color(NamedTextColor.YELLOW));

        Component footer = Component.text("")
            .append(Component.text("Ping: ").color(NamedTextColor.GRAY))
            .append(Component.text(ping + "ms").color(getPingColor(ping)));

        player.sendPlayerListHeaderAndFooter(header, footer);
    }

    private NamedTextColor getPingColor(int ping) {
        if (ping < 50) return NamedTextColor.GREEN;
        if (ping < 100) return NamedTextColor.YELLOW;
        if (ping < 200) return NamedTextColor.GOLD;
        return NamedTextColor.RED;
    }

    public void updateAllPlayersTab() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            updatePlayerTab(player);
        }
    }

    public void cleanup() {
        savePlayerData();
    }

    public Map<Integer, CargoInfo> getCargos() {
        return cargos;
    }

    public boolean isValidRank(int rank) {
        return cargos.containsKey(rank);
    }
}
