package com.ranktab.plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class InvCheckManager {

    private final RankTabPlugin plugin;
    private final Map<UUID, Boolean> invisibleAdmins = new HashMap<>();
    private final Map<UUID, UUID> viewingInventory = new HashMap<>();

    public InvCheckManager(RankTabPlugin plugin) {
        this.plugin = plugin;
    }

    public void toggleInvisible(Player player) {
        UUID uuid = player.getUniqueId();
        boolean isInvisible = invisibleAdmins.getOrDefault(uuid, false);

        if (isInvisible) {
            // Desativa invisibilidade
            invisibleAdmins.put(uuid, false);
            player.setInvisible(false);

            // Mostra para todos os jogadores
            for (Player online : Bukkit.getOnlinePlayers()) {
                online.showPlayer(plugin, player);
            }

            player.sendMessage(Component.text("Modo invisivel DESATIVADO").color(NamedTextColor.RED));
        } else {
            // Ativa invisibilidade
            invisibleAdmins.put(uuid, true);
            player.setInvisible(true);

            // Esconde de todos os jogadores (exceto outros admins com permissao)
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (!online.hasPermission("ranktabplugin.invcheck")) {
                    online.hidePlayer(plugin, player);
                }
            }

            player.sendMessage(Component.text("Modo invisivel ATIVADO").color(NamedTextColor.GREEN));
            player.sendMessage(Component.text("Shift + Click Direito em um jogador para ver o inventario").color(NamedTextColor.YELLOW));
        }
    }

    public boolean isInvisible(Player player) {
        return invisibleAdmins.getOrDefault(player.getUniqueId(), false);
    }

    public void openPlayerInventory(Player admin, Player target) {
        if (!isInvisible(admin)) {
            admin.sendMessage(Component.text("Voce precisa estar invisivel! Use /inv primeiro").color(NamedTextColor.RED));
            return;
        }

        // Cria um inventario espelho do jogador
        Inventory inv = Bukkit.createInventory(null, 45, Component.text("Inv de ").color(NamedTextColor.DARK_GRAY)
            .append(Component.text(target.getName()).color(NamedTextColor.YELLOW)));

        // Copia itens do inventario do jogador
        ItemStack[] contents = target.getInventory().getContents();
        for (int i = 0; i < contents.length && i < 36; i++) {
            if (contents[i] != null) {
                inv.setItem(i, contents[i].clone());
            }
        }

        // Armadura (slots 36-39)
        ItemStack[] armor = target.getInventory().getArmorContents();
        for (int i = 0; i < armor.length && i < 4; i++) {
            if (armor[i] != null) {
                inv.setItem(36 + i, armor[i].clone());
            }
        }

        // Item na mao secundaria (slot 40)
        if (target.getInventory().getItemInOffHand() != null) {
            inv.setItem(40, target.getInventory().getItemInOffHand().clone());
        }

        viewingInventory.put(admin.getUniqueId(), target.getUniqueId());
        admin.openInventory(inv);

        // Envia aviso de invisibilidade
        new BukkitRunnable() {
            @Override
            public void run() {
                if (admin.getOpenInventory() != null && admin.getOpenInventory().getTitle().toString().contains("Inv de")) {
                    admin.sendActionBar(Component.text("VOCE ESTA INVISIVEL").color(NamedTextColor.GREEN).decorate(net.kyori.adventure.text.format.TextDecoration.BOLD));
                } else {
                    this.cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    public void openPlayerInventoryRemote(Player admin, Player target) {
        // Cria um inventario espelho do jogador
        Inventory inv = Bukkit.createInventory(null, 45, Component.text("Inv de ").color(NamedTextColor.DARK_GRAY)
            .append(Component.text(target.getName()).color(NamedTextColor.YELLOW)));

        // Copia itens do inventario do jogador
        ItemStack[] contents = target.getInventory().getContents();
        for (int i = 0; i < contents.length && i < 36; i++) {
            if (contents[i] != null) {
                inv.setItem(i, contents[i].clone());
            }
        }

        // Armadura (slots 36-39)
        ItemStack[] armor = target.getInventory().getArmorContents();
        for (int i = 0; i < armor.length && i < 4; i++) {
            if (armor[i] != null) {
                inv.setItem(36 + i, armor[i].clone());
            }
        }

        // Item na mao secundaria (slot 40)
        if (target.getInventory().getItemInOffHand() != null) {
            inv.setItem(40, target.getInventory().getItemInOffHand().clone());
        }

        viewingInventory.put(admin.getUniqueId(), target.getUniqueId());
        admin.openInventory(inv);
    }

    public UUID getViewingTarget(UUID adminUuid) {
        return viewingInventory.get(adminUuid);
    }

    public void removeViewing(UUID adminUuid) {
        viewingInventory.remove(adminUuid);
    }

    public void updateInvisibleForNewPlayer(Player newPlayer) {
        for (Map.Entry<UUID, Boolean> entry : invisibleAdmins.entrySet()) {
            if (entry.getValue()) {
                Player admin = Bukkit.getPlayer(entry.getKey());
                if (admin != null && admin.isOnline()) {
                    if (!newPlayer.hasPermission("ranktabplugin.invcheck")) {
                        newPlayer.hidePlayer(plugin, admin);
                    }
                }
            }
        }
    }
}
