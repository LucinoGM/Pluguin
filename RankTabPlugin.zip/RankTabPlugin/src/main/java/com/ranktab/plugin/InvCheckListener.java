package com.ranktab.plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;

public class InvCheckListener implements Listener {

    private final RankTabPlugin plugin;

    public InvCheckListener(RankTabPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player newPlayer = event.getPlayer();
        plugin.getInvCheckManager().updateInvisibleForNewPlayer(newPlayer);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractAtEntityEvent event) {
        Player admin = event.getPlayer();

        if (!(event.getRightClicked() instanceof Player)) return;
        if (!admin.isSneaking()) return;

        Player target = (Player) event.getRightClicked();

        if (!plugin.getInvCheckManager().isInvisible(admin)) return;
        if (!admin.hasPermission("ranktabplugin.invcheck")) return;

        event.setCancelled(true);
        plugin.getInvCheckManager().openPlayerInventory(admin, target);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;

        Player admin = (Player) event.getWhoClicked();
        String title = event.getView().title().toString();

        if (!title.contains("Inv de ")) return;

        UUID targetUuid = plugin.getInvCheckManager().getViewingTarget(admin.getUniqueId());
        if (targetUuid == null) return;

        Player target = Bukkit.getPlayer(targetUuid);
        if (target == null || !target.isOnline()) {
            admin.sendMessage(Component.text("Jogador saiu do servidor!").color(NamedTextColor.RED));
            admin.closeInventory();
            return;
        }

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= 45) return;

        event.setCancelled(false); // Permite mover itens

        // Sincroniza mudancas no inventario do jogador
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            ItemStack newItem = event.getInventory().getItem(slot);

            if (slot < 36) {
                // Inventario principal
                target.getInventory().setItem(slot, newItem);
            } else if (slot < 40) {
                // Armadura
                int armorSlot = slot - 36;
                ItemStack[] armor = target.getInventory().getArmorContents();
                armor[armorSlot] = newItem;
                target.getInventory().setArmorContents(armor);
            } else if (slot == 40) {
                // Mao secundaria
                target.getInventory().setItemInOffHand(newItem);
            }
        }, 1L);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player)) return;

        Player admin = (Player) event.getPlayer();
        String title = event.getView().title().toString();

        if (title.contains("Inv de ")) {
            plugin.getInvCheckManager().removeViewing(admin.getUniqueId());
        }
    }
}
