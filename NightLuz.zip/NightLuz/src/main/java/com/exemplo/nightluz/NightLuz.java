package com.exemplo.nightluz;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class NightLuz extends JavaPlugin {

    private static final int SEGUNDOS_ACTIONBAR = 10;
    private final Map<UUID, BukkitTask> tarefas = new HashMap<>();

    @Override
    public void onEnable() {
        getLogger().info("NightLuz ativado!");
    }

    @Override
    public void onDisable() {
        tarefas.values().forEach(BukkitTask::cancel);
        tarefas.clear();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores podem usar este comando.");
            return true;
        }
        if (!player.hasPermission("nightluz.use")) {
            player.sendMessage(Component.text("Você não tem permissão.", NamedTextColor.RED));
            return true;
        }

        boolean estavaAtivo = player.hasPotionEffect(PotionEffectType.NIGHT_VISION);

        if (estavaAtivo) {
            player.removePotionEffect(PotionEffectType.NIGHT_VISION);
        } else {
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.NIGHT_VISION,
                    PotionEffect.INFINITE_DURATION,
                    0,
                    false,  // ambient
                    false,  // partículas
                    false   // ícone
            ));
        }

        Component msg = estavaAtivo
                ? Component.text("Night Vision desativada", NamedTextColor.RED)
                : Component.text("Night Vision ativada", NamedTextColor.GREEN);

        player.sendMessage(msg);       // chat
        mostrarActionBar(player, msg); // acima da barra de XP por 10s
        return true;
    }

    private void mostrarActionBar(Player player, Component msg) {
        BukkitTask antiga = tarefas.remove(player.getUniqueId());
        if (antiga != null) antiga.cancel();

        BukkitTask nova = new BukkitRunnable() {
            int segundos = 0;

            @Override
            public void run() {
                if (!player.isOnline() || segundos >= SEGUNDOS_ACTIONBAR) {
                    if (player.isOnline()) player.sendActionBar(Component.empty());
                    tarefas.remove(player.getUniqueId());
                    cancel();
                    return;
                }
                player.sendActionBar(msg);
                segundos++;
            }
        }.runTaskTimer(this, 0L, 20L);

        tarefas.put(player.getUniqueId(), nova);
    }
}
